class InstanceNorm2d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = ["running_mean", "running_var", "num_batches_tracked", ]
  weight : NoneType
  bias : NoneType
  running_mean : NoneType
  running_var : NoneType
  num_batches_tracked : NoneType
  training : bool
  _is_full_backward_hook : NoneType
  eps : Final[float] = 1.0000000000000001e-05
  num_features : Final[int] = 96
  affine : Final[bool] = False
  momentum : Final[float] = 0.10000000000000001
  track_running_stats : Final[bool] = False
  def forward(self: __torch__.torch.nn.modules.instancenorm.___torch_mangle_3.InstanceNorm2d,
    input: Tensor) -> Tensor:
    _0 = (self)._check_input_dim(input, )
    _1 = torch.eq(torch.dim(input), (self)._get_no_batch_dim())
    if _1:
      _3 = (self)._handle_no_batch_input(input, )
      _2 = _3
    else:
      _4 = (self)._apply_instance_norm(input, )
      _2 = _4
    return _2
  def _check_input_dim(self: __torch__.torch.nn.modules.instancenorm.___torch_mangle_3.InstanceNorm2d,
    input: Tensor) -> NoneType:
    _5 = "expected 3D or 4D input (got {}D input)"
    _6 = torch.dim(input)
    _7 = torch.__not__(torch.__contains__([3, 4], _6))
    if _7:
      _8 = torch.format(_5, torch.dim(input))
      ops.prim.RaiseException(_8, "builtins.ValueError")
    else:
      pass
    return None
  def _get_no_batch_dim(self: __torch__.torch.nn.modules.instancenorm.___torch_mangle_3.InstanceNorm2d) -> int:
    return 3
  def _handle_no_batch_input(self: __torch__.torch.nn.modules.instancenorm.___torch_mangle_3.InstanceNorm2d,
    input: Tensor) -> Tensor:
    _9 = (self)._apply_instance_norm(torch.unsqueeze(input, 0), )
    return torch.squeeze(_9, 0)
  def _apply_instance_norm(self: __torch__.torch.nn.modules.instancenorm.___torch_mangle_3.InstanceNorm2d,
    input: Tensor) -> Tensor:
    _10 = __torch__.torch.nn.functional.instance_norm
    running_mean = self.running_mean
    running_var = self.running_var
    weight = self.weight
    bias = self.bias
    _11 = _10(input, running_mean, running_var, weight, bias, True, 0.10000000000000001, 1.0000000000000001e-05, )
    return _11
