def unfold(input: Tensor,
    kernel_size: List[int],
    dilation: List[int]=[1, 1],
    padding: List[int]=[0, 0],
    stride: List[int]=[1, 1]) -> Tensor:
  _0 = torch.im2col(input, kernel_size, dilation, padding, stride)
  return _0
def instance_norm(input: Tensor,
    running_mean: Optional[Tensor]=None,
    running_var: Optional[Tensor]=None,
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    use_input_stats: bool=True,
    momentum: float=0.10000000000000001,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _1 = __torch__.torch.nn.functional._verify_spatial_size
  if use_input_stats:
    _2 = _1(torch.size(input), )
  else:
    pass
  _3 = torch.instance_norm(input, weight, bias, running_mean, running_var, use_input_stats, momentum, eps, True)
  return _3
def relu(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    result = torch.relu_(input)
  else:
    result = torch.relu(input)
  return result
def batch_norm(input: Tensor,
    running_mean: Optional[Tensor],
    running_var: Optional[Tensor],
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    training: bool=False,
    momentum: float=0.10000000000000001,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _4 = __torch__.torch.nn.functional._verify_batch_size
  if training:
    _5 = _4(torch.size(input), )
  else:
    pass
  _6 = torch.batch_norm(input, weight, bias, running_mean, running_var, training, momentum, eps, True)
  return _6
def _verify_spatial_size(size: List[int]) -> NoneType:
  _7 = "Expected more than 1 spatial element when training, got input size {}"
  _8 = torch.__range_length(2, torch.len(size), 1)
  size_prods = 1
  for _9 in range(_8):
    i = torch.__derive_index(_9, 2, 1)
    size_prods = torch.mul(size_prods, size[i])
  if torch.eq(size_prods, 1):
    ops.prim.RaiseException(torch.format(_7, size), "builtins.ValueError")
  else:
    pass
  return None
def _verify_batch_size(size: List[int]) -> NoneType:
  _10 = "Expected more than 1 value per channel when training, got input size {}"
  size_prods = size[0]
  size_prods0 = size_prods
  for i in range(torch.sub(torch.len(size), 2)):
    size_prods1 = torch.mul(size_prods0, size[torch.add(i, 2)])
    size_prods0 = size_prods1
  if torch.eq(size_prods0, 1):
    ops.prim.RaiseException(torch.format(_10, size), "builtins.ValueError")
  else:
    pass
  return None
def grid_sample(input: Tensor,
    grid: Tensor,
    mode: str="bilinear",
    padding_mode: str="zeros",
    align_corners: Optional[bool]=None) -> Tensor:
  _11 = "nn.functional.grid_sample(): expected mode to be \'bilinear\', \'nearest\' or \'bicubic\', but got: \'{}\'"
  _12 = "nn.functional.grid_sample(): expected padding_mode to be \'zeros\', \'border\', or \'reflection\', but got: \'{}\'"
  _13 = "Default grid_sample and affine_grid behavior has changed to align_corners=False since 1.3.0. Please specify align_corners=True if the old behavior is desired. See the documentation of grid_sample for details."
  if torch.ne(mode, "bilinear"):
    _14 = torch.ne(mode, "nearest")
  else:
    _14 = False
  if _14:
    _15 = torch.ne(mode, "bicubic")
  else:
    _15 = False
  if _15:
    ops.prim.RaiseException(torch.format(_11, mode), "builtins.ValueError")
  else:
    pass
  if torch.ne(padding_mode, "zeros"):
    _16 = torch.ne(padding_mode, "border")
  else:
    _16 = False
  if _16:
    _18 = torch.ne(padding_mode, "reflection")
    _17 = _18
  else:
    _17 = False
  if _17:
    ops.prim.RaiseException(torch.format(_12, padding_mode), "builtins.ValueError")
  else:
    pass
  if torch.eq(mode, "bilinear"):
    mode_enum = 0
  else:
    if torch.eq(mode, "nearest"):
      mode_enum0 = 1
    else:
      mode_enum0 = 2
    mode_enum = mode_enum0
  if torch.eq(padding_mode, "zeros"):
    padding_mode_enum = 0
  else:
    if torch.eq(padding_mode, "border"):
      padding_mode_enum0 = 1
    else:
      padding_mode_enum0 = 2
    padding_mode_enum = padding_mode_enum0
  if torch.__is__(align_corners, None):
    torch.warn(_13)
    align_corners0 = False
  else:
    align_corners0 = unchecked_cast(bool, align_corners)
  _19 = torch.grid_sampler(input, grid, mode_enum, padding_mode_enum, align_corners0)
  return _19
