def accumulate_flows_torch(flows: Tensor) -> Tensor:
  _0 = annotate(List[Tensor], [])
  _1 = torch.slice(torch.select(flows, 0, 0))
  accumulated_flow = torch.clone(torch.slice(torch.slice(_1, 1), 2))
  _2 = torch.append(_0, torch.clone(accumulated_flow))
  accumulated_flow0 = accumulated_flow
  i = 1
  _3 = torch.lt(1, (torch.size(flows))[0])
  while _3:
    _4 = torch.slice(torch.select(flows, 0, i))
    _5 = torch.clone(torch.slice(torch.slice(_4, 1), 2))
    warped_flow = __torch__.utils.utils.warp_flow_torch(_5, torch.clone(accumulated_flow0), )
    accumulated_flow1 = torch.add_(accumulated_flow0, warped_flow)
    _6 = torch.append(_0, torch.clone(accumulated_flow1))
    i0 = torch.add(i, 1)
    _7 = torch.lt(i0, (torch.size(flows))[0])
    _3, accumulated_flow0, i = _7, accumulated_flow1, i0
  return torch.stack(_0)
def coords_grid(batch: int,
    ht: int,
    wd: int,
    device: Device) -> Tensor:
  _8 = torch.arange(ht, dtype=None, layout=None, device=device)
  _9 = torch.arange(wd, dtype=None, layout=None, device=device)
  coords = torch.meshgrid([_8, _9])
  _10 = torch.stack(torch.slice(coords, None, None, -1))
  coords0 = torch.to(_10, 6)
  _11 = torch.repeat(torch.unsqueeze(coords0, 0), [batch, 1, 1, 1])
  return _11
def warp_flow_torch(flow: Tensor,
    flow_to_warp: Tensor) -> Tensor:
  _12 = __torch__.torch.nn.functional.grid_sample
  h, w, = torch.slice(torch.size(flow), 1)
  _13 = torch.meshgrid([torch.arange(h), torch.arange(w)])
  grid_y, grid_x, = _13
  _14 = torch.to(torch.stack([grid_x, grid_y], 2), 6)
  grid = torch.to(_14, ops.prim.device(flow))
  _15 = torch.select(torch.slice(torch.slice(grid), 1), 2, 0)
  _16 = torch.slice(torch.select(flow_to_warp, 0, 0))
  map_x = torch.add(_15, torch.slice(_16, 1))
  _17 = torch.select(torch.slice(torch.slice(grid), 1), 2, 1)
  _18 = torch.slice(torch.select(flow_to_warp, 0, 1))
  map_y = torch.add(_17, torch.slice(_18, 1))
  _19 = torch.div(torch.mul(map_x, 2.), torch.sub(w, 1))
  map_x0 = torch.sub(_19, 1.)
  _20 = torch.div(torch.mul(map_y, 2.), torch.sub(h, 1))
  map_y0 = torch.sub(_20, 1.)
  map_xy = torch.stack([map_x0, map_y0], 2)
  map_xy0 = torch.unsqueeze(map_xy, 0)
  flow0 = torch.unsqueeze(flow, 0)
  _21 = torch.slice(torch.slice(torch.slice(flow0), 1), 2)
  warped_flow_x = _12(torch.slice(_21, 3), map_xy0, "bilinear", "zeros", None, )
  return torch.select(warped_flow_x, 0, 0)
def bilinear_sampler(img: Tensor,
    coords: Tensor) -> Tensor:
  _22 = __torch__.torch.nn.functional.grid_sample
  H, W, = torch.slice(torch.size(img), -2)
  xgrid, ygrid, = torch.split(coords, [1, 1], -1)
  _23 = torch.div(torch.mul(xgrid, 2), torch.sub(W, 1))
  xgrid0 = torch.sub(_23, 1)
  _24 = torch.div(torch.mul(ygrid, 2), torch.sub(H, 1))
  ygrid0 = torch.sub(_24, 1)
  grid = torch.cat([xgrid0, ygrid0], -1)
  img0 = _22(img, grid, "bilinear", "zeros", True, )
  return img0
