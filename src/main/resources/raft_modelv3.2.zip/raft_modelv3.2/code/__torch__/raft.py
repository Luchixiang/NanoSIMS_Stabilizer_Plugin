class RAFT(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  hidden_dim : int
  context_dim : int
  fnet : __torch__.extractor.BasicEncoder
  cnet : __torch__.extractor.___torch_mangle_30.BasicEncoder
  update_block : __torch__.update.BasicUpdateBlock
  def forward(self: __torch__.raft.RAFT,
    image1: Tensor,
    image2: Tensor) -> Tensor:
    _0 = __torch__.utils.utils.accumulate_flows_torch
    _1 = torch.mul(torch.div(image1, 255.), 2)
    image10 = torch.sub(_1, 1.)
    _2 = torch.mul(torch.div(image2, 255.), 2)
    image20 = torch.sub(_2, 1.)
    image11 = torch.contiguous(image10)
    image21 = torch.contiguous(image20)
    hidden_dim = self.hidden_dim
    context_dim = self.context_dim
    fnet = self.fnet
    _3 = (fnet).forward([image11, image21], )
    fmap1, fmap2, = _3
    fmap10 = torch.to(fmap1, 6)
    fmap20 = torch.to(fmap2, 6)
    corr_fn = __torch__.corr.CorrBlock.__new__(__torch__.corr.CorrBlock)
    _4 = (corr_fn).__init__(fmap10, fmap20, 4, 4, )
    cnet = self.cnet
    cnet0 = ((cnet).forward([image11], ))[0]
    _5 = torch.split(cnet0, [hidden_dim, context_dim], 1)
    net, inp, = _5
    net0 = torch.tanh(net)
    inp0 = torch.relu(inp)
    coords0, coords1, = (self).initialize_flow(image11, )
    _6 = annotate(List[Tensor], [])
    coords10 = coords1
    net1 = net0
    for itr in range(20):
      coords11 = torch.detach(coords10)
      corr = (corr_fn).__call__(coords11, )
      flow = torch.sub(coords11, coords0)
      update_block = self.update_block
      _7 = (update_block).forward(net1, inp0, corr, flow, )
      net2, up_mask, delta_flow, = _7
      coords12 = torch.add(coords11, delta_flow)
      flow_up = (self).upsample_flow(torch.sub(coords12, coords0), up_mask, )
      _8 = torch.append(_6, flow_up)
      coords10, net1 = coords12, net2
    flow_up0 = _6[-1]
    _9 = torch.gt((torch.size(flow_up0))[0], 1)
    if _9:
      flow_up1 = _0(flow_up0, )
    else:
      flow_up1 = flow_up0
    return flow_up1
  def initialize_flow(self: __torch__.raft.RAFT,
    img: Tensor) -> Tuple[Tensor, Tensor]:
    N, C, H, W, = torch.size(img)
    coords0 = __torch__.utils.utils.coords_grid(N, torch.floordiv(H, 8), torch.floordiv(W, 8), ops.prim.device(img), )
    coords1 = __torch__.utils.utils.coords_grid(N, torch.floordiv(H, 8), torch.floordiv(W, 8), ops.prim.device(img), )
    return (coords0, coords1)
  def upsample_flow(self: __torch__.raft.RAFT,
    flow: Tensor,
    mask: Tensor) -> Tensor:
    _10 = __torch__.torch.nn.functional.unfold
    N, _11, H, W, = torch.size(flow)
    mask0 = torch.view(mask, [N, 1, 9, 8, 8, H, W])
    mask1 = torch.softmax(mask0, 2)
    up_flow = _10(torch.mul(flow, 8), [3, 3], [1, 1], [1, 1], [1, 1], )
    up_flow0 = torch.view(up_flow, [N, 2, 9, 1, 1, H, W])
    up_flow1 = torch.sum(torch.mul(mask1, up_flow0), [2])
    up_flow2 = torch.permute(up_flow1, [0, 1, 4, 2, 5, 3])
    _12 = [N, 2, torch.mul(8, H), torch.mul(8, W)]
    return torch.reshape(up_flow2, _12)
