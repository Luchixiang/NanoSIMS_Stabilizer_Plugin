class BasicUpdateBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  encoder : __torch__.update.BasicMotionEncoder
  gru : __torch__.update.SepConvGRU
  flow_head : __torch__.update.FlowHead
  mask : __torch__.torch.nn.modules.container.___torch_mangle_41.Sequential
  def forward(self: __torch__.update.BasicUpdateBlock,
    net: Tensor,
    inp: Tensor,
    corr: Tensor,
    flow: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    encoder = self.encoder
    motion_features = (encoder).forward(flow, corr, )
    inp0 = torch.cat([inp, motion_features], 1)
    gru = self.gru
    net0 = (gru).forward(net, inp0, )
    flow_head = self.flow_head
    delta_flow = (flow_head).forward(net0, )
    mask = self.mask
    mask0 = torch.mul((mask).forward(net0, ), 0.25)
    return (net0, mask0, delta_flow)
class BasicMotionEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  convc1 : __torch__.torch.nn.modules.conv.___torch_mangle_31.Conv2d
  convc2 : __torch__.torch.nn.modules.conv.___torch_mangle_32.Conv2d
  convf1 : __torch__.torch.nn.modules.conv.___torch_mangle_33.Conv2d
  convf2 : __torch__.torch.nn.modules.conv.___torch_mangle_34.Conv2d
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_35.Conv2d
  def forward(self: __torch__.update.BasicMotionEncoder,
    flow: Tensor,
    corr: Tensor) -> Tensor:
    convc1 = self.convc1
    cor = __torch__.torch.nn.functional.relu((convc1).forward(corr, ), False, )
    convc2 = self.convc2
    cor0 = __torch__.torch.nn.functional.relu((convc2).forward(cor, ), False, )
    convf1 = self.convf1
    flo = __torch__.torch.nn.functional.relu((convf1).forward(flow, ), False, )
    convf2 = self.convf2
    flo0 = __torch__.torch.nn.functional.relu((convf2).forward(flo, ), False, )
    cor_flo = torch.cat([cor0, flo0], 1)
    conv = self.conv
    out = __torch__.torch.nn.functional.relu((conv).forward(cor_flo, ), False, )
    return torch.cat([out, flow], 1)
class SepConvGRU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  convz1 : __torch__.torch.nn.modules.conv.___torch_mangle_36.Conv2d
  convr1 : __torch__.torch.nn.modules.conv.___torch_mangle_36.Conv2d
  convq1 : __torch__.torch.nn.modules.conv.___torch_mangle_36.Conv2d
  convz2 : __torch__.torch.nn.modules.conv.___torch_mangle_37.Conv2d
  convr2 : __torch__.torch.nn.modules.conv.___torch_mangle_37.Conv2d
  convq2 : __torch__.torch.nn.modules.conv.___torch_mangle_37.Conv2d
  def forward(self: __torch__.update.SepConvGRU,
    h: Tensor,
    x: Tensor) -> Tensor:
    hx = torch.cat([h, x], 1)
    convz1 = self.convz1
    z = torch.sigmoid((convz1).forward(hx, ))
    convr1 = self.convr1
    r = torch.sigmoid((convr1).forward(hx, ))
    convq1 = self.convq1
    _0 = (convq1).forward(torch.cat([torch.mul(r, h), x], 1), )
    q = torch.tanh(_0)
    _1 = torch.mul(torch.add(torch.neg(z), 1), h)
    h0 = torch.add(_1, torch.mul(z, q))
    hx0 = torch.cat([h0, x], 1)
    convz2 = self.convz2
    z0 = torch.sigmoid((convz2).forward(hx0, ))
    convr2 = self.convr2
    r0 = torch.sigmoid((convr2).forward(hx0, ))
    convq2 = self.convq2
    _2 = torch.cat([torch.mul(r0, h0), x], 1)
    q0 = torch.tanh((convq2).forward(_2, ))
    _3 = torch.mul(torch.add(torch.neg(z0), 1), h0)
    return torch.add(_3, torch.mul(z0, q0))
class FlowHead(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_38.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_39.Conv2d
  relu : __torch__.torch.nn.modules.activation.ReLU
  def forward(self: __torch__.update.FlowHead,
    x: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _4 = (relu).forward((conv1).forward(x, ), )
    return (conv2).forward(_4, )
