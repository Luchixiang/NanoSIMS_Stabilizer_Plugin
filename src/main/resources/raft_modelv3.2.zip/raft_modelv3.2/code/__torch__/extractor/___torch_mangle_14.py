class ResidualBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_9.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_10.Conv2d
  relu : __torch__.torch.nn.modules.activation.ReLU
  norm1 : __torch__.torch.nn.modules.instancenorm.___torch_mangle_11.InstanceNorm2d
  norm2 : __torch__.torch.nn.modules.instancenorm.___torch_mangle_11.InstanceNorm2d
  norm3 : __torch__.torch.nn.modules.instancenorm.___torch_mangle_11.InstanceNorm2d
  downsample : __torch__.torch.nn.modules.container.___torch_mangle_13.Sequential
  def forward(self: __torch__.extractor.___torch_mangle_14.ResidualBlock,
    x: Tensor) -> Tensor:
    relu = self.relu
    norm1 = self.norm1
    conv1 = self.conv1
    _0 = (norm1).forward((conv1).forward(x, ), )
    y = (relu).forward(_0, )
    relu0 = self.relu
    norm2 = self.norm2
    conv2 = self.conv2
    _1 = (norm2).forward((conv2).forward(y, ), )
    y0 = (relu0).forward(_1, )
    downsample = self.downsample
    x0 = (downsample).forward(x, )
    relu1 = self.relu
    _2 = (relu1).forward(torch.add(x0, y0), )
    return _2
