class ResidualBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  downsample : NoneType
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv2d
  relu : __torch__.torch.nn.modules.activation.ReLU
  norm1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_20.BatchNorm2d
  norm2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_20.BatchNorm2d
  def forward(self: __torch__.extractor.___torch_mangle_23.ResidualBlock,
    x: Tensor) -> Tensor:
    relu = self.relu
    norm1 = self.norm1
    conv1 = self.conv1
    _0 = (norm1).forward((conv1).forward(x, ), )
    y = (relu).forward(_0, )
    relu0 = self.relu
    norm2 = self.norm2
    conv2 = self.conv2
    _1 = (norm2).forward((conv2).forward(y, ), )
    y0 = (relu0).forward(_1, )
    relu1 = self.relu
    return (relu1).forward(torch.add(x, y0), )
