class CorrBlock:
  num_levels : int
  radius : int
  corr_pyramid : List[Tensor]
  def __call__(self: __torch__.corr.CorrBlock,
    coords: Tensor) -> Tensor:
    _0 = __torch__.utils.utils.bilinear_sampler
    radius = self.radius
    coords0 = torch.permute(coords, [0, 2, 3, 1])
    batch, h1, w1, _1, = torch.size(coords0)
    _2 = annotate(List[Tensor], [])
    num_levels = self.num_levels
    for i in range(num_levels):
      corr_pyramid = self.corr_pyramid
      corr = corr_pyramid[i]
      _3 = torch.neg(radius)
      _4 = torch.add(torch.mul(2, radius), 1)
      dx = torch.linspace(_3, radius, _4, dtype=None, layout=None, device=ops.prim.device(coords0))
      _5 = torch.neg(radius)
      _6 = torch.add(torch.mul(2, radius), 1)
      dy = torch.linspace(_5, radius, _6, dtype=None, layout=None, device=ops.prim.device(coords0))
      delta = torch.stack(torch.meshgrid([dy, dx]), -1)
      _7 = torch.mul(torch.mul(batch, h1), w1)
      _8 = torch.reshape(coords0, [_7, 1, 1, 2])
      centroid_lvl = torch.div(_8, torch.pow(2, i))
      _9 = torch.add(torch.mul(2, radius), 1)
      _10 = torch.add(torch.mul(2, radius), 1)
      delta_lvl = torch.view(delta, [1, _9, _10, 2])
      coords_lvl = torch.add(centroid_lvl, delta_lvl)
      corr0 = _0(corr, coords_lvl, )
      corr1 = torch.view(corr0, [batch, h1, w1, -1])
      _11 = torch.append(_2, corr1)
    out = torch.cat(_2, -1)
    _12 = torch.contiguous(torch.permute(out, [0, 3, 1, 2]))
    return torch.to(_12, 6)
  def __init__(self: __torch__.corr.CorrBlock,
    fmap1: Tensor,
    fmap2: Tensor,
    num_levels: int=4,
    radius: int=4) -> NoneType:
    self.num_levels = num_levels
    self.radius = radius
    self.corr_pyramid = annotate(List[Tensor], [])
    corr = __torch__.corr.corr(fmap1, fmap2, )
    batch, h1, w1, dim, h2, w2, = torch.size(corr)
    _13 = [torch.mul(torch.mul(batch, h1), w1), dim, h2, w2]
    corr2 = torch.reshape(corr, _13)
    corr_pyramid = self.corr_pyramid
    _14 = torch.append(corr_pyramid, corr2)
    num_levels0 = self.num_levels
    corr3 = corr2
    for i in range(torch.sub(num_levels0, 1)):
      corr4 = torch.avg_pool2d(corr3, [2, 2], [2, 2])
      corr_pyramid0 = self.corr_pyramid
      _15 = torch.append(corr_pyramid0, corr4)
      corr3 = corr4
    return None
def corr(fmap1: Tensor,
    fmap2: Tensor) -> Tensor:
  batch, dim, ht, wd, = torch.size(fmap1)
  fmap10 = torch.view(fmap1, [batch, dim, torch.mul(ht, wd)])
  fmap20 = torch.view(fmap2, [batch, dim, torch.mul(ht, wd)])
  corr = torch.matmul(torch.transpose(fmap10, 1, 2), fmap20)
  corr5 = torch.view(corr, [batch, ht, wd, 1, ht, wd])
  _16 = torch.sqrt(torch.to(torch.tensor(dim), 6))
  return torch.div(corr5, _16)
