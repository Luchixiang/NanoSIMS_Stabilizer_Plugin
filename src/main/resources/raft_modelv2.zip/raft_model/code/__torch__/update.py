class BasicUpdateBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  encoder : __torch__.update.BasicMotionEncoder
  gru : __torch__.update.SepConvGRU
  flow_head : __torch__.update.FlowHead
  mask : __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential
  def forward(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input0: Tensor,
    inp: Tensor,
    h: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _0 = [inp, (encoder).forward(input, input0, )]
    x = torch.cat(_0, 1)
    _1 = (gru).forward(h, x, )
    _2 = (flow_head).forward(_1, )
    mask0 = torch.mul((mask).forward(_1, ), CONSTANTS.c6)
    return (_2, mask0, _1, _1, _1)
  def forward1(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input1: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _3 = [inp, (encoder).forward1(input, input1, )]
    x = torch.cat(_3, 1)
    _4 = (gru).forward1(argument_4, x, argument_5, argument_6, )
    _5 = (flow_head).forward1(_4, )
    mask1 = torch.mul((mask).forward1(_4, ), CONSTANTS.c6)
    return (_5, mask1, _4, _4, _4)
  def forward2(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input2: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _6 = [inp, (encoder).forward2(input, input2, )]
    x = torch.cat(_6, 1)
    _7 = (gru).forward2(argument_4, x, argument_5, argument_6, )
    _8 = (flow_head).forward2(_7, )
    mask2 = torch.mul((mask).forward2(_7, ), CONSTANTS.c6)
    return (_8, mask2, _7, _7, _7)
  def forward3(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input3: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _9 = [inp, (encoder).forward3(input, input3, )]
    x = torch.cat(_9, 1)
    _10 = (gru).forward3(argument_4, x, argument_5, argument_6, )
    _11 = (flow_head).forward3(_10, )
    mask3 = torch.mul((mask).forward3(_10, ), CONSTANTS.c6)
    return (_11, mask3, _10, _10, _10)
  def forward4(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input4: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _12 = [inp, (encoder).forward4(input, input4, )]
    x = torch.cat(_12, 1)
    _13 = (gru).forward4(argument_4, x, argument_5, argument_6, )
    _14 = (flow_head).forward4(_13, )
    mask4 = torch.mul((mask).forward4(_13, ), CONSTANTS.c6)
    return (_14, mask4, _13, _13, _13)
  def forward5(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input5: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _15 = [inp, (encoder).forward5(input, input5, )]
    x = torch.cat(_15, 1)
    _16 = (gru).forward5(argument_4, x, argument_5, argument_6, )
    _17 = (flow_head).forward5(_16, )
    mask5 = torch.mul((mask).forward5(_16, ), CONSTANTS.c6)
    return (_17, mask5, _16, _16, _16)
  def forward6(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input6: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _18 = [inp, (encoder).forward6(input, input6, )]
    x = torch.cat(_18, 1)
    _19 = (gru).forward6(argument_4, x, argument_5, argument_6, )
    _20 = (flow_head).forward6(_19, )
    mask6 = torch.mul((mask).forward6(_19, ), CONSTANTS.c6)
    return (_20, mask6, _19, _19, _19)
  def forward7(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input7: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _21 = [inp, (encoder).forward7(input, input7, )]
    x = torch.cat(_21, 1)
    _22 = (gru).forward7(argument_4, x, argument_5, argument_6, )
    _23 = (flow_head).forward7(_22, )
    mask7 = torch.mul((mask).forward7(_22, ), CONSTANTS.c6)
    return (_23, mask7, _22, _22, _22)
  def forward8(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input8: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _24 = [inp, (encoder).forward8(input, input8, )]
    x = torch.cat(_24, 1)
    _25 = (gru).forward8(argument_4, x, argument_5, argument_6, )
    _26 = (flow_head).forward8(_25, )
    mask8 = torch.mul((mask).forward8(_25, ), CONSTANTS.c6)
    return (_26, mask8, _25, _25, _25)
  def forward9(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input9: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _27 = [inp, (encoder).forward9(input, input9, )]
    x = torch.cat(_27, 1)
    _28 = (gru).forward9(argument_4, x, argument_5, argument_6, )
    _29 = (flow_head).forward9(_28, )
    mask9 = torch.mul((mask).forward9(_28, ), CONSTANTS.c6)
    return (_29, mask9, _28, _28, _28)
  def forward10(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input10: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _30 = (encoder).forward10(input, input10, )
    x = torch.cat([inp, _30], 1)
    _31 = (gru).forward10(argument_4, x, argument_5, argument_6, )
    _32 = (flow_head).forward10(_31, )
    mask10 = torch.mul((mask).forward10(_31, ), CONSTANTS.c6)
    return (_32, mask10, _31, _31, _31)
  def forward11(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input11: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _33 = (encoder).forward11(input, input11, )
    x = torch.cat([inp, _33], 1)
    _34 = (gru).forward11(argument_4, x, argument_5, argument_6, )
    _35 = (flow_head).forward11(_34, )
    mask11 = torch.mul((mask).forward11(_34, ), CONSTANTS.c6)
    return (_35, mask11, _34, _34, _34)
  def forward12(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input12: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _36 = (encoder).forward12(input, input12, )
    x = torch.cat([inp, _36], 1)
    _37 = (gru).forward12(argument_4, x, argument_5, argument_6, )
    _38 = (flow_head).forward12(_37, )
    mask12 = torch.mul((mask).forward12(_37, ), CONSTANTS.c6)
    return (_38, mask12, _37, _37, _37)
  def forward13(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input13: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _39 = (encoder).forward13(input, input13, )
    x = torch.cat([inp, _39], 1)
    _40 = (gru).forward13(argument_4, x, argument_5, argument_6, )
    _41 = (flow_head).forward13(_40, )
    mask13 = torch.mul((mask).forward13(_40, ), CONSTANTS.c6)
    return (_41, mask13, _40, _40, _40)
  def forward14(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input14: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _42 = (encoder).forward14(input, input14, )
    x = torch.cat([inp, _42], 1)
    _43 = (gru).forward14(argument_4, x, argument_5, argument_6, )
    _44 = (flow_head).forward14(_43, )
    mask14 = torch.mul((mask).forward14(_43, ), CONSTANTS.c6)
    return (_44, mask14, _43, _43, _43)
  def forward15(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input15: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _45 = (encoder).forward15(input, input15, )
    x = torch.cat([inp, _45], 1)
    _46 = (gru).forward15(argument_4, x, argument_5, argument_6, )
    _47 = (flow_head).forward15(_46, )
    mask15 = torch.mul((mask).forward15(_46, ), CONSTANTS.c6)
    return (_47, mask15, _46, _46, _46)
  def forward16(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input16: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _48 = (encoder).forward16(input, input16, )
    x = torch.cat([inp, _48], 1)
    _49 = (gru).forward16(argument_4, x, argument_5, argument_6, )
    _50 = (flow_head).forward16(_49, )
    mask16 = torch.mul((mask).forward16(_49, ), CONSTANTS.c6)
    return (_50, mask16, _49, _49, _49)
  def forward17(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input17: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _51 = (encoder).forward17(input, input17, )
    x = torch.cat([inp, _51], 1)
    _52 = (gru).forward17(argument_4, x, argument_5, argument_6, )
    _53 = (flow_head).forward17(_52, )
    mask17 = torch.mul((mask).forward17(_52, ), CONSTANTS.c6)
    return (_53, mask17, _52, _52, _52)
  def forward18(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input18: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _54 = (encoder).forward18(input, input18, )
    x = torch.cat([inp, _54], 1)
    _55 = (gru).forward18(argument_4, x, argument_5, argument_6, )
    _56 = (flow_head).forward18(_55, )
    mask18 = torch.mul((mask).forward18(_55, ), CONSTANTS.c6)
    return (_56, mask18, _55, _55, _55)
  def forward19(self: __torch__.update.BasicUpdateBlock,
    input: Tensor,
    input19: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _57 = (encoder).forward19(input, input19, )
    x = torch.cat([inp, _57], 1)
    _58 = (gru).forward19(argument_4, x, argument_5, argument_6, )
    _59 = (flow_head).forward19(_58, )
    mask19 = torch.mul((mask).forward19(_58, ), CONSTANTS.c6)
    return (_59, mask19)
class BasicMotionEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  convc1 : __torch__.torch.nn.modules.conv.___torch_mangle_97.Conv2d
  convc2 : __torch__.torch.nn.modules.conv.___torch_mangle_98.Conv2d
  convf1 : __torch__.torch.nn.modules.conv.___torch_mangle_99.Conv2d
  convf2 : __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_101.Conv2d
  def forward(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input20: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input21 = torch.relu((convc1).forward(input, ))
    cor = torch.relu((convc2).forward(input21, ))
    input22 = torch.relu((convf1).forward(input20, ))
    flo = torch.relu((convf2).forward(input22, ))
    input23 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward(input23, ))
    return torch.cat([out, input20], 1)
  def forward1(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input24: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input25 = torch.relu((convc1).forward1(input, ))
    cor = torch.relu((convc2).forward1(input25, ))
    input26 = torch.relu((convf1).forward1(input24, ))
    flo = torch.relu((convf2).forward1(input26, ))
    input27 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward1(input27, ))
    return torch.cat([out, input24], 1)
  def forward2(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input28: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input29 = torch.relu((convc1).forward2(input, ))
    cor = torch.relu((convc2).forward2(input29, ))
    input30 = torch.relu((convf1).forward2(input28, ))
    flo = torch.relu((convf2).forward2(input30, ))
    input31 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward2(input31, ))
    return torch.cat([out, input28], 1)
  def forward3(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input32: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input33 = torch.relu((convc1).forward3(input, ))
    cor = torch.relu((convc2).forward3(input33, ))
    input34 = torch.relu((convf1).forward3(input32, ))
    flo = torch.relu((convf2).forward3(input34, ))
    input35 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward3(input35, ))
    return torch.cat([out, input32], 1)
  def forward4(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input36: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input37 = torch.relu((convc1).forward4(input, ))
    cor = torch.relu((convc2).forward4(input37, ))
    input38 = torch.relu((convf1).forward4(input36, ))
    flo = torch.relu((convf2).forward4(input38, ))
    input39 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward4(input39, ))
    return torch.cat([out, input36], 1)
  def forward5(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input40: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input41 = torch.relu((convc1).forward5(input, ))
    cor = torch.relu((convc2).forward5(input41, ))
    input42 = torch.relu((convf1).forward5(input40, ))
    flo = torch.relu((convf2).forward5(input42, ))
    input43 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward5(input43, ))
    return torch.cat([out, input40], 1)
  def forward6(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input44: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input45 = torch.relu((convc1).forward6(input, ))
    cor = torch.relu((convc2).forward6(input45, ))
    input46 = torch.relu((convf1).forward6(input44, ))
    flo = torch.relu((convf2).forward6(input46, ))
    input47 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward6(input47, ))
    return torch.cat([out, input44], 1)
  def forward7(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input48: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input49 = torch.relu((convc1).forward7(input, ))
    cor = torch.relu((convc2).forward7(input49, ))
    input50 = torch.relu((convf1).forward7(input48, ))
    flo = torch.relu((convf2).forward7(input50, ))
    input51 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward7(input51, ))
    return torch.cat([out, input48], 1)
  def forward8(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input52: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input53 = torch.relu((convc1).forward8(input, ))
    cor = torch.relu((convc2).forward8(input53, ))
    input54 = torch.relu((convf1).forward8(input52, ))
    flo = torch.relu((convf2).forward8(input54, ))
    input55 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward8(input55, ))
    return torch.cat([out, input52], 1)
  def forward9(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input56: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input57 = torch.relu((convc1).forward9(input, ))
    cor = torch.relu((convc2).forward9(input57, ))
    input58 = torch.relu((convf1).forward9(input56, ))
    flo = torch.relu((convf2).forward9(input58, ))
    input59 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward9(input59, ))
    return torch.cat([out, input56], 1)
  def forward10(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input60: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input61 = torch.relu((convc1).forward10(input, ))
    cor = torch.relu((convc2).forward10(input61, ))
    input62 = torch.relu((convf1).forward10(input60, ))
    flo = torch.relu((convf2).forward10(input62, ))
    input63 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward10(input63, ))
    return torch.cat([out, input60], 1)
  def forward11(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input64: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input65 = torch.relu((convc1).forward11(input, ))
    cor = torch.relu((convc2).forward11(input65, ))
    input66 = torch.relu((convf1).forward11(input64, ))
    flo = torch.relu((convf2).forward11(input66, ))
    input67 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward11(input67, ))
    return torch.cat([out, input64], 1)
  def forward12(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input68: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input69 = torch.relu((convc1).forward12(input, ))
    cor = torch.relu((convc2).forward12(input69, ))
    input70 = torch.relu((convf1).forward12(input68, ))
    flo = torch.relu((convf2).forward12(input70, ))
    input71 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward12(input71, ))
    return torch.cat([out, input68], 1)
  def forward13(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input72: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input73 = torch.relu((convc1).forward13(input, ))
    cor = torch.relu((convc2).forward13(input73, ))
    input74 = torch.relu((convf1).forward13(input72, ))
    flo = torch.relu((convf2).forward13(input74, ))
    input75 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward13(input75, ))
    return torch.cat([out, input72], 1)
  def forward14(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input76: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input77 = torch.relu((convc1).forward14(input, ))
    cor = torch.relu((convc2).forward14(input77, ))
    input78 = torch.relu((convf1).forward14(input76, ))
    flo = torch.relu((convf2).forward14(input78, ))
    input79 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward14(input79, ))
    return torch.cat([out, input76], 1)
  def forward15(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input80: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input81 = torch.relu((convc1).forward15(input, ))
    cor = torch.relu((convc2).forward15(input81, ))
    input82 = torch.relu((convf1).forward15(input80, ))
    flo = torch.relu((convf2).forward15(input82, ))
    input83 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward15(input83, ))
    return torch.cat([out, input80], 1)
  def forward16(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input84: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input85 = torch.relu((convc1).forward16(input, ))
    cor = torch.relu((convc2).forward16(input85, ))
    input86 = torch.relu((convf1).forward16(input84, ))
    flo = torch.relu((convf2).forward16(input86, ))
    input87 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward16(input87, ))
    return torch.cat([out, input84], 1)
  def forward17(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input88: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input89 = torch.relu((convc1).forward17(input, ))
    cor = torch.relu((convc2).forward17(input89, ))
    input90 = torch.relu((convf1).forward17(input88, ))
    flo = torch.relu((convf2).forward17(input90, ))
    input91 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward17(input91, ))
    return torch.cat([out, input88], 1)
  def forward18(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input92: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input93 = torch.relu((convc1).forward18(input, ))
    cor = torch.relu((convc2).forward18(input93, ))
    input94 = torch.relu((convf1).forward18(input92, ))
    flo = torch.relu((convf2).forward18(input94, ))
    input95 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward18(input95, ))
    return torch.cat([out, input92], 1)
  def forward19(self: __torch__.update.BasicMotionEncoder,
    input: Tensor,
    input96: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input97 = torch.relu((convc1).forward19(input, ))
    cor = torch.relu((convc2).forward19(input97, ))
    input98 = torch.relu((convf1).forward19(input96, ))
    flo = torch.relu((convf2).forward19(input98, ))
    input99 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward19(input99, ))
    return torch.cat([out, input96], 1)
class SepConvGRU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  convz1 : __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d
  convr1 : __torch__.torch.nn.modules.conv.___torch_mangle_103.Conv2d
  convq1 : __torch__.torch.nn.modules.conv.___torch_mangle_104.Conv2d
  convz2 : __torch__.torch.nn.modules.conv.___torch_mangle_105.Conv2d
  convr2 : __torch__.torch.nn.modules.conv.___torch_mangle_106.Conv2d
  convq2 : __torch__.torch.nn.modules.conv.___torch_mangle_107.Conv2d
  def forward(self: __torch__.update.SepConvGRU,
    h: Tensor,
    x: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([h, x], 1)
    z = torch.sigmoid((convz1).forward(input, ))
    r = torch.sigmoid((convr1).forward(input, ))
    input100 = torch.cat([torch.mul(r, h), x], 1)
    q = torch.tanh((convq1).forward(input100, ))
    h0 = torch.add(torch.mul(torch.rsub(z, 1), h), torch.mul(z, q))
    input101 = torch.cat([h0, x], 1)
    z0 = torch.sigmoid((convz2).forward(input101, ))
    r0 = torch.sigmoid((convr2).forward(input101, ))
    input102 = torch.cat([torch.mul(r0, h0), x], 1)
    q0 = torch.tanh((convq2).forward(input102, ))
    input103 = torch.add(torch.mul(torch.rsub(z0, 1), h0), torch.mul(z0, q0))
    return input103
  def forward1(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward1(input, ))
    r = torch.sigmoid((convr1).forward1(input, ))
    input104 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward1(input104, ))
    _60 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_60, torch.mul(z, q))
    input105 = torch.cat([h, x], 1)
    z1 = torch.sigmoid((convz2).forward1(input105, ))
    r1 = torch.sigmoid((convr2).forward1(input105, ))
    input106 = torch.cat([torch.mul(r1, h), x], 1)
    q1 = torch.tanh((convq2).forward1(input106, ))
    input107 = torch.add(torch.mul(torch.rsub(z1, 1), h), torch.mul(z1, q1))
    return input107
  def forward2(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward2(input, ))
    r = torch.sigmoid((convr1).forward2(input, ))
    input108 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward2(input108, ))
    _61 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_61, torch.mul(z, q))
    input109 = torch.cat([h, x], 1)
    z2 = torch.sigmoid((convz2).forward2(input109, ))
    r2 = torch.sigmoid((convr2).forward2(input109, ))
    input110 = torch.cat([torch.mul(r2, h), x], 1)
    q2 = torch.tanh((convq2).forward2(input110, ))
    input111 = torch.add(torch.mul(torch.rsub(z2, 1), h), torch.mul(z2, q2))
    return input111
  def forward3(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward3(input, ))
    r = torch.sigmoid((convr1).forward3(input, ))
    input112 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward3(input112, ))
    _62 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_62, torch.mul(z, q))
    input113 = torch.cat([h, x], 1)
    z3 = torch.sigmoid((convz2).forward3(input113, ))
    r3 = torch.sigmoid((convr2).forward3(input113, ))
    input114 = torch.cat([torch.mul(r3, h), x], 1)
    q3 = torch.tanh((convq2).forward3(input114, ))
    input115 = torch.add(torch.mul(torch.rsub(z3, 1), h), torch.mul(z3, q3))
    return input115
  def forward4(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward4(input, ))
    r = torch.sigmoid((convr1).forward4(input, ))
    input116 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward4(input116, ))
    _63 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_63, torch.mul(z, q))
    input117 = torch.cat([h, x], 1)
    z4 = torch.sigmoid((convz2).forward4(input117, ))
    r4 = torch.sigmoid((convr2).forward4(input117, ))
    input118 = torch.cat([torch.mul(r4, h), x], 1)
    q4 = torch.tanh((convq2).forward4(input118, ))
    input119 = torch.add(torch.mul(torch.rsub(z4, 1), h), torch.mul(z4, q4))
    return input119
  def forward5(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward5(input, ))
    r = torch.sigmoid((convr1).forward5(input, ))
    input120 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward5(input120, ))
    _64 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_64, torch.mul(z, q))
    input121 = torch.cat([h, x], 1)
    z5 = torch.sigmoid((convz2).forward5(input121, ))
    r5 = torch.sigmoid((convr2).forward5(input121, ))
    input122 = torch.cat([torch.mul(r5, h), x], 1)
    q5 = torch.tanh((convq2).forward5(input122, ))
    input123 = torch.add(torch.mul(torch.rsub(z5, 1), h), torch.mul(z5, q5))
    return input123
  def forward6(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward6(input, ))
    r = torch.sigmoid((convr1).forward6(input, ))
    input124 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward6(input124, ))
    _65 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_65, torch.mul(z, q))
    input125 = torch.cat([h, x], 1)
    z6 = torch.sigmoid((convz2).forward6(input125, ))
    r6 = torch.sigmoid((convr2).forward6(input125, ))
    input126 = torch.cat([torch.mul(r6, h), x], 1)
    q6 = torch.tanh((convq2).forward6(input126, ))
    input127 = torch.add(torch.mul(torch.rsub(z6, 1), h), torch.mul(z6, q6))
    return input127
  def forward7(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward7(input, ))
    r = torch.sigmoid((convr1).forward7(input, ))
    input128 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward7(input128, ))
    _66 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_66, torch.mul(z, q))
    input129 = torch.cat([h, x], 1)
    z7 = torch.sigmoid((convz2).forward7(input129, ))
    r7 = torch.sigmoid((convr2).forward7(input129, ))
    input130 = torch.cat([torch.mul(r7, h), x], 1)
    q7 = torch.tanh((convq2).forward7(input130, ))
    input131 = torch.add(torch.mul(torch.rsub(z7, 1), h), torch.mul(z7, q7))
    return input131
  def forward8(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward8(input, ))
    r = torch.sigmoid((convr1).forward8(input, ))
    input132 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward8(input132, ))
    _67 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_67, torch.mul(z, q))
    input133 = torch.cat([h, x], 1)
    z8 = torch.sigmoid((convz2).forward8(input133, ))
    r8 = torch.sigmoid((convr2).forward8(input133, ))
    input134 = torch.cat([torch.mul(r8, h), x], 1)
    q8 = torch.tanh((convq2).forward8(input134, ))
    input135 = torch.add(torch.mul(torch.rsub(z8, 1), h), torch.mul(z8, q8))
    return input135
  def forward9(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward9(input, ))
    r = torch.sigmoid((convr1).forward9(input, ))
    input136 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward9(input136, ))
    _68 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_68, torch.mul(z, q))
    input137 = torch.cat([h, x], 1)
    z9 = torch.sigmoid((convz2).forward9(input137, ))
    r9 = torch.sigmoid((convr2).forward9(input137, ))
    input138 = torch.cat([torch.mul(r9, h), x], 1)
    q9 = torch.tanh((convq2).forward9(input138, ))
    input139 = torch.add(torch.mul(torch.rsub(z9, 1), h), torch.mul(z9, q9))
    return input139
  def forward10(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward10(input, ))
    r = torch.sigmoid((convr1).forward10(input, ))
    input140 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward10(input140, ))
    _69 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_69, torch.mul(z, q))
    input141 = torch.cat([h, x], 1)
    z10 = torch.sigmoid((convz2).forward10(input141, ))
    r10 = torch.sigmoid((convr2).forward10(input141, ))
    input142 = torch.cat([torch.mul(r10, h), x], 1)
    q10 = torch.tanh((convq2).forward10(input142, ))
    input143 = torch.add(torch.mul(torch.rsub(z10, 1), h), torch.mul(z10, q10))
    return input143
  def forward11(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward11(input, ))
    r = torch.sigmoid((convr1).forward11(input, ))
    input144 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward11(input144, ))
    _70 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_70, torch.mul(z, q))
    input145 = torch.cat([h, x], 1)
    z11 = torch.sigmoid((convz2).forward11(input145, ))
    r11 = torch.sigmoid((convr2).forward11(input145, ))
    input146 = torch.cat([torch.mul(r11, h), x], 1)
    q11 = torch.tanh((convq2).forward11(input146, ))
    input147 = torch.add(torch.mul(torch.rsub(z11, 1), h), torch.mul(z11, q11))
    return input147
  def forward12(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward12(input, ))
    r = torch.sigmoid((convr1).forward12(input, ))
    input148 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward12(input148, ))
    _71 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_71, torch.mul(z, q))
    input149 = torch.cat([h, x], 1)
    z12 = torch.sigmoid((convz2).forward12(input149, ))
    r12 = torch.sigmoid((convr2).forward12(input149, ))
    input150 = torch.cat([torch.mul(r12, h), x], 1)
    q12 = torch.tanh((convq2).forward12(input150, ))
    input151 = torch.add(torch.mul(torch.rsub(z12, 1), h), torch.mul(z12, q12))
    return input151
  def forward13(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward13(input, ))
    r = torch.sigmoid((convr1).forward13(input, ))
    input152 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward13(input152, ))
    _72 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_72, torch.mul(z, q))
    input153 = torch.cat([h, x], 1)
    z13 = torch.sigmoid((convz2).forward13(input153, ))
    r13 = torch.sigmoid((convr2).forward13(input153, ))
    input154 = torch.cat([torch.mul(r13, h), x], 1)
    q13 = torch.tanh((convq2).forward13(input154, ))
    input155 = torch.add(torch.mul(torch.rsub(z13, 1), h), torch.mul(z13, q13))
    return input155
  def forward14(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward14(input, ))
    r = torch.sigmoid((convr1).forward14(input, ))
    input156 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward14(input156, ))
    _73 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_73, torch.mul(z, q))
    input157 = torch.cat([h, x], 1)
    z14 = torch.sigmoid((convz2).forward14(input157, ))
    r14 = torch.sigmoid((convr2).forward14(input157, ))
    input158 = torch.cat([torch.mul(r14, h), x], 1)
    q14 = torch.tanh((convq2).forward14(input158, ))
    input159 = torch.add(torch.mul(torch.rsub(z14, 1), h), torch.mul(z14, q14))
    return input159
  def forward15(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward15(input, ))
    r = torch.sigmoid((convr1).forward15(input, ))
    input160 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward15(input160, ))
    _74 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_74, torch.mul(z, q))
    input161 = torch.cat([h, x], 1)
    z15 = torch.sigmoid((convz2).forward15(input161, ))
    r15 = torch.sigmoid((convr2).forward15(input161, ))
    input162 = torch.cat([torch.mul(r15, h), x], 1)
    q15 = torch.tanh((convq2).forward15(input162, ))
    input163 = torch.add(torch.mul(torch.rsub(z15, 1), h), torch.mul(z15, q15))
    return input163
  def forward16(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward16(input, ))
    r = torch.sigmoid((convr1).forward16(input, ))
    input164 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward16(input164, ))
    _75 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_75, torch.mul(z, q))
    input165 = torch.cat([h, x], 1)
    z16 = torch.sigmoid((convz2).forward16(input165, ))
    r16 = torch.sigmoid((convr2).forward16(input165, ))
    input166 = torch.cat([torch.mul(r16, h), x], 1)
    q16 = torch.tanh((convq2).forward16(input166, ))
    input167 = torch.add(torch.mul(torch.rsub(z16, 1), h), torch.mul(z16, q16))
    return input167
  def forward17(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward17(input, ))
    r = torch.sigmoid((convr1).forward17(input, ))
    input168 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward17(input168, ))
    _76 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_76, torch.mul(z, q))
    input169 = torch.cat([h, x], 1)
    z17 = torch.sigmoid((convz2).forward17(input169, ))
    r17 = torch.sigmoid((convr2).forward17(input169, ))
    input170 = torch.cat([torch.mul(r17, h), x], 1)
    q17 = torch.tanh((convq2).forward17(input170, ))
    input171 = torch.add(torch.mul(torch.rsub(z17, 1), h), torch.mul(z17, q17))
    return input171
  def forward18(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward18(input, ))
    r = torch.sigmoid((convr1).forward18(input, ))
    input172 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward18(input172, ))
    _77 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_77, torch.mul(z, q))
    input173 = torch.cat([h, x], 1)
    z18 = torch.sigmoid((convz2).forward18(input173, ))
    r18 = torch.sigmoid((convr2).forward18(input173, ))
    input174 = torch.cat([torch.mul(r18, h), x], 1)
    q18 = torch.tanh((convq2).forward18(input174, ))
    input175 = torch.add(torch.mul(torch.rsub(z18, 1), h), torch.mul(z18, q18))
    return input175
  def forward19(self: __torch__.update.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward19(input, ))
    r = torch.sigmoid((convr1).forward19(input, ))
    input176 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward19(input176, ))
    _78 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_78, torch.mul(z, q))
    input177 = torch.cat([h, x], 1)
    z19 = torch.sigmoid((convz2).forward19(input177, ))
    r19 = torch.sigmoid((convr2).forward19(input177, ))
    input178 = torch.cat([torch.mul(r19, h), x], 1)
    q19 = torch.tanh((convq2).forward19(input178, ))
    input179 = torch.add(torch.mul(torch.rsub(z19, 1), h), torch.mul(z19, q19))
    return input179
class FlowHead(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_108.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d
  relu : __torch__.torch.nn.modules.activation.___torch_mangle_110.ReLU
  def forward(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _79 = (relu).forward((conv1).forward(argument_1, ), )
    return (conv2).forward(_79, )
  def forward1(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _80 = (relu).forward1((conv1).forward1(argument_1, ), )
    return (conv2).forward1(_80, )
  def forward2(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _81 = (relu).forward2((conv1).forward2(argument_1, ), )
    return (conv2).forward2(_81, )
  def forward3(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _82 = (relu).forward3((conv1).forward3(argument_1, ), )
    return (conv2).forward3(_82, )
  def forward4(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _83 = (relu).forward4((conv1).forward4(argument_1, ), )
    return (conv2).forward4(_83, )
  def forward5(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _84 = (relu).forward5((conv1).forward5(argument_1, ), )
    return (conv2).forward5(_84, )
  def forward6(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _85 = (relu).forward6((conv1).forward6(argument_1, ), )
    return (conv2).forward6(_85, )
  def forward7(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _86 = (relu).forward7((conv1).forward7(argument_1, ), )
    return (conv2).forward7(_86, )
  def forward8(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _87 = (relu).forward8((conv1).forward8(argument_1, ), )
    return (conv2).forward8(_87, )
  def forward9(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _88 = (relu).forward9((conv1).forward9(argument_1, ), )
    return (conv2).forward9(_88, )
  def forward10(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _89 = (relu).forward10((conv1).forward10(argument_1, ), )
    return (conv2).forward10(_89, )
  def forward11(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _90 = (relu).forward11((conv1).forward11(argument_1, ), )
    return (conv2).forward11(_90, )
  def forward12(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _91 = (relu).forward12((conv1).forward12(argument_1, ), )
    return (conv2).forward12(_91, )
  def forward13(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _92 = (relu).forward13((conv1).forward13(argument_1, ), )
    return (conv2).forward13(_92, )
  def forward14(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _93 = (relu).forward14((conv1).forward14(argument_1, ), )
    return (conv2).forward14(_93, )
  def forward15(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _94 = (relu).forward15((conv1).forward15(argument_1, ), )
    return (conv2).forward15(_94, )
  def forward16(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _95 = (relu).forward16((conv1).forward16(argument_1, ), )
    return (conv2).forward16(_95, )
  def forward17(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _96 = (relu).forward17((conv1).forward17(argument_1, ), )
    return (conv2).forward17(_96, )
  def forward18(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _97 = (relu).forward18((conv1).forward18(argument_1, ), )
    return (conv2).forward18(_97, )
  def forward19(self: __torch__.update.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _98 = (relu).forward19((conv1).forward19(argument_1, ), )
    return (conv2).forward19(_98, )
