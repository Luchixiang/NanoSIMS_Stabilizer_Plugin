class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.torch.nn.modules.conv.___torch_mangle_111.Conv2d
  __annotations__["1"] = __torch__.torch.nn.modules.activation.___torch_mangle_112.ReLU
  __annotations__["2"] = __torch__.torch.nn.modules.conv.___torch_mangle_113.Conv2d
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _3 = (_1).forward((_0).forward(argument_1, ), )
    return (_2).forward(_3, )
  def forward1(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _3 = (_1).forward1((_0).forward1(argument_1, ), )
    return (_2).forward1(_3, )
  def forward2(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _3 = (_1).forward2((_0).forward2(argument_1, ), )
    return (_2).forward2(_3, )
  def forward3(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _3 = (_1).forward3((_0).forward3(argument_1, ), )
    return (_2).forward3(_3, )
  def forward4(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _4 = (_1).forward4((_0).forward4(argument_1, ), )
    return (_2).forward4(_4, )
  def forward5(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _5 = (_1).forward5((_0).forward5(argument_1, ), )
    return (_2).forward5(_5, )
  def forward6(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _6 = (_1).forward6((_0).forward6(argument_1, ), )
    return (_2).forward6(_6, )
  def forward7(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _7 = (_1).forward7((_0).forward7(argument_1, ), )
    return (_2).forward7(_7, )
  def forward8(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _8 = (_1).forward8((_0).forward8(argument_1, ), )
    return (_2).forward8(_8, )
  def forward9(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _9 = (_1).forward9((_0).forward9(argument_1, ), )
    return (_2).forward9(_9, )
  def forward10(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _10 = (_1).forward10((_0).forward10(argument_1, ), )
    return (_2).forward10(_10, )
  def forward11(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _11 = (_1).forward11((_0).forward11(argument_1, ), )
    return (_2).forward11(_11, )
  def forward12(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _12 = (_1).forward12((_0).forward12(argument_1, ), )
    return (_2).forward12(_12, )
  def forward13(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _13 = (_1).forward13((_0).forward13(argument_1, ), )
    return (_2).forward13(_13, )
  def forward14(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _14 = (_1).forward14((_0).forward14(argument_1, ), )
    return (_2).forward14(_14, )
  def forward15(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _15 = (_1).forward15((_0).forward15(argument_1, ), )
    return (_2).forward15(_15, )
  def forward16(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _16 = (_1).forward16((_0).forward16(argument_1, ), )
    return (_2).forward16(_16, )
  def forward17(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _17 = (_1).forward17((_0).forward17(argument_1, ), )
    return (_2).forward17(_17, )
  def forward18(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _18 = (_1).forward18((_0).forward18(argument_1, ), )
    return (_2).forward18(_18, )
  def forward19(self: __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential,
    argument_1: Tensor) -> Tensor:
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _19 = (_1).forward19((_0).forward19(argument_1, ), )
    return (_2).forward19(_19, )
