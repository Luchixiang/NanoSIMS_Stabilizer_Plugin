class InstanceNorm2d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.instancenorm.___torch_mangle_32.InstanceNorm2d,
    argument_1: Tensor) -> Tensor:
    input = torch.instance_norm(argument_1, None, None, None, None, True, 0.10000000000000001, 1.0000000000000001e-05, True)
    return input
