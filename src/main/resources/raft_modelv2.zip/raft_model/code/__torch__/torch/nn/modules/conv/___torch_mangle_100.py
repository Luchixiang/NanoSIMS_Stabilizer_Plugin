class Conv2d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input0 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input0
  def forward1(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input1 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input1
  def forward2(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input2 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input2
  def forward3(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input3 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input3
  def forward4(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input4 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input4
  def forward5(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input5 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input5
  def forward6(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input6 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input6
  def forward7(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input7 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input7
  def forward8(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input8 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input8
  def forward9(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input9 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input9
  def forward10(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input10 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input10
  def forward11(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input11 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input11
  def forward12(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input12 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input12
  def forward13(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input13 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input13
  def forward14(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input14 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input14
  def forward15(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input15 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input15
  def forward16(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input16 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input16
  def forward17(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input17 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input17
  def forward18(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input18 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input18
  def forward19(self: __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    input19 = torch._convolution(input, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return input19
