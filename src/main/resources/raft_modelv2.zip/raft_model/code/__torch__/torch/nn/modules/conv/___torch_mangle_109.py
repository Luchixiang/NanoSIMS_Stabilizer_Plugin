class Conv2d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward1(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward2(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward3(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward4(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward5(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward6(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward7(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward8(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward9(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward10(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward11(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward12(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward13(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward14(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward15(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward16(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward17(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward18(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
  def forward19(self: __torch__.torch.nn.modules.conv.___torch_mangle_109.Conv2d,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    delta_flow = torch._convolution(argument_1, weight, bias, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True, True)
    return delta_flow
