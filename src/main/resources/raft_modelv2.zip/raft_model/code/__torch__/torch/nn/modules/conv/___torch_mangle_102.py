class Conv2d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _0 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _0
  def forward1(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _1 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _1
  def forward2(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _2 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _2
  def forward3(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _3 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _3
  def forward4(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _4 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _4
  def forward5(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _5 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _5
  def forward6(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _6 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _6
  def forward7(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _7 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _7
  def forward8(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _8 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _8
  def forward9(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _9 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _9
  def forward10(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _10 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _10
  def forward11(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _11 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _11
  def forward12(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _12 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _12
  def forward13(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _13 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _13
  def forward14(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _14 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _14
  def forward15(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _15 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _15
  def forward16(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _16 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _16
  def forward17(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _17 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _17
  def forward18(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _18 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _18
  def forward19(self: __torch__.torch.nn.modules.conv.___torch_mangle_102.Conv2d,
    input: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _19 = torch._convolution(input, weight, bias, [1, 1], [0, 2], [1, 1], False, [0, 0], 1, False, False, True, True)
    return _19
