class BasicEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm1 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_46.Conv2d
  relu1 : __torch__.torch.nn.modules.activation.___torch_mangle_47.ReLU
  layer1 : __torch__.torch.nn.modules.container.___torch_mangle_60.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_77.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_94.Sequential
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_95.Conv2d
  def forward(self: __torch__.extractor.___torch_mangle_96.BasicEncoder,
    input: Tensor) -> Tensor:
    conv2 = self.conv2
    layer3 = self.layer3
    layer2 = self.layer2
    layer1 = self.layer1
    relu1 = self.relu1
    norm1 = self.norm1
    conv1 = self.conv1
    _0 = (norm1).forward((conv1).forward(input, ), )
    _1 = (layer1).forward((relu1).forward(_0, ), )
    _2 = (layer3).forward((layer2).forward(_1, ), )
    return (conv2).forward(_2, )
