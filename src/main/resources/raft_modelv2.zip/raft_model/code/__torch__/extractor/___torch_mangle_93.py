class ResidualBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_88.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_89.Conv2d
  relu : __torch__.torch.nn.modules.activation.___torch_mangle_90.ReLU
  norm1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_91.BatchNorm2d
  norm2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_92.BatchNorm2d
  def forward(self: __torch__.extractor.___torch_mangle_93.ResidualBlock,
    argument_1: Tensor) -> Tensor:
    norm2 = self.norm2
    conv2 = self.conv2
    relu = self.relu
    norm1 = self.norm1
    conv1 = self.conv1
    _0 = (norm1).forward((conv1).forward(argument_1, ), )
    _1 = (conv2).forward((relu).forward(_0, ), )
    _2 = (relu).forward1((norm2).forward(_1, ), )
    input = torch.add(argument_1, _2)
    return (relu).forward2(input, )
