class BasicEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm1 : __torch__.torch.nn.modules.instancenorm.InstanceNorm2d
  conv1 : __torch__.torch.nn.modules.conv.Conv2d
  relu1 : __torch__.torch.nn.modules.activation.ReLU
  layer1 : __torch__.torch.nn.modules.container.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_27.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_44.Sequential
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_45.Conv2d
  def forward(self: __torch__.extractor.BasicEncoder,
    input: Tensor,
    argument_2: Tensor) -> Tuple[Tensor, Tensor]:
    conv2 = self.conv2
    layer3 = self.layer3
    layer2 = self.layer2
    layer1 = self.layer1
    relu1 = self.relu1
    norm1 = self.norm1
    conv1 = self.conv1
    _0 = ops.prim.NumToTensor(torch.size(input, 0))
    _1 = int(_0)
    _2 = int(_0)
    input0 = torch.cat([input, argument_2])
    _3 = (norm1).forward((conv1).forward(input0, ), )
    _4 = (layer1).forward((relu1).forward(_3, ), )
    _5 = (layer3).forward((layer2).forward(_4, ), )
    _6 = torch.split_with_sizes((conv2).forward(_5, ), [_2, _1])
    fmap1, fmap2, = _6
    return (fmap1, fmap2)
class ResidualBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_1.Conv2d
  relu : __torch__.torch.nn.modules.activation.___torch_mangle_2.ReLU
  norm1 : __torch__.torch.nn.modules.instancenorm.___torch_mangle_3.InstanceNorm2d
  norm2 : __torch__.torch.nn.modules.instancenorm.___torch_mangle_4.InstanceNorm2d
  def forward(self: __torch__.extractor.ResidualBlock,
    argument_1: Tensor) -> Tensor:
    norm2 = self.norm2
    conv2 = self.conv2
    relu = self.relu
    norm1 = self.norm1
    conv1 = self.conv1
    _7 = (norm1).forward((conv1).forward(argument_1, ), )
    _8 = (conv2).forward((relu).forward(_7, ), )
    _9 = (relu).forward1((norm2).forward(_8, ), )
    input = torch.add(argument_1, _9)
    return (relu).forward2(input, )
