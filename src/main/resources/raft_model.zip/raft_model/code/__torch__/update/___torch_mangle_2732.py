class BasicUpdateBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  encoder : __torch__.update.___torch_mangle_2716.BasicMotionEncoder
  gru : __torch__.update.___torch_mangle_2723.SepConvGRU
  flow_head : __torch__.update.___torch_mangle_2727.FlowHead
  mask : __torch__.torch.nn.modules.container.___torch_mangle_2731.Sequential
  def forward(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input0: Tensor,
    inp: Tensor,
    h: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _0 = [inp, (encoder).forward(input, input0, )]
    x = torch.cat(_0, 1)
    _1 = (gru).forward(h, x, )
    _2 = (flow_head).forward(_1, )
    mask0 = torch.mul((mask).forward(_1, ), CONSTANTS.c6)
    return (_2, mask0, _1, _1, _1)
  def forward1(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input1: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _3 = [inp, (encoder).forward1(input, input1, )]
    x = torch.cat(_3, 1)
    _4 = (gru).forward1(argument_4, x, argument_5, argument_6, )
    _5 = (flow_head).forward1(_4, )
    mask1 = torch.mul((mask).forward1(_4, ), CONSTANTS.c6)
    return (_5, mask1, _4, _4, _4)
  def forward2(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input2: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _6 = [inp, (encoder).forward2(input, input2, )]
    x = torch.cat(_6, 1)
    _7 = (gru).forward2(argument_4, x, argument_5, argument_6, )
    _8 = (flow_head).forward2(_7, )
    mask2 = torch.mul((mask).forward2(_7, ), CONSTANTS.c6)
    return (_8, mask2, _7, _7, _7)
  def forward3(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input3: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _9 = [inp, (encoder).forward3(input, input3, )]
    x = torch.cat(_9, 1)
    _10 = (gru).forward3(argument_4, x, argument_5, argument_6, )
    _11 = (flow_head).forward3(_10, )
    mask3 = torch.mul((mask).forward3(_10, ), CONSTANTS.c6)
    return (_11, mask3, _10, _10, _10)
  def forward4(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input4: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _12 = [inp, (encoder).forward4(input, input4, )]
    x = torch.cat(_12, 1)
    _13 = (gru).forward4(argument_4, x, argument_5, argument_6, )
    _14 = (flow_head).forward4(_13, )
    mask4 = torch.mul((mask).forward4(_13, ), CONSTANTS.c6)
    return (_14, mask4, _13, _13, _13)
  def forward5(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input5: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _15 = [inp, (encoder).forward5(input, input5, )]
    x = torch.cat(_15, 1)
    _16 = (gru).forward5(argument_4, x, argument_5, argument_6, )
    _17 = (flow_head).forward5(_16, )
    mask5 = torch.mul((mask).forward5(_16, ), CONSTANTS.c6)
    return (_17, mask5, _16, _16, _16)
  def forward6(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input6: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _18 = [inp, (encoder).forward6(input, input6, )]
    x = torch.cat(_18, 1)
    _19 = (gru).forward6(argument_4, x, argument_5, argument_6, )
    _20 = (flow_head).forward6(_19, )
    mask6 = torch.mul((mask).forward6(_19, ), CONSTANTS.c6)
    return (_20, mask6, _19, _19, _19)
  def forward7(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input7: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _21 = [inp, (encoder).forward7(input, input7, )]
    x = torch.cat(_21, 1)
    _22 = (gru).forward7(argument_4, x, argument_5, argument_6, )
    _23 = (flow_head).forward7(_22, )
    mask7 = torch.mul((mask).forward7(_22, ), CONSTANTS.c6)
    return (_23, mask7, _22, _22, _22)
  def forward8(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input8: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _24 = [inp, (encoder).forward8(input, input8, )]
    x = torch.cat(_24, 1)
    _25 = (gru).forward8(argument_4, x, argument_5, argument_6, )
    _26 = (flow_head).forward8(_25, )
    mask8 = torch.mul((mask).forward8(_25, ), CONSTANTS.c6)
    return (_26, mask8, _25, _25, _25)
  def forward9(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input9: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _27 = [inp, (encoder).forward9(input, input9, )]
    x = torch.cat(_27, 1)
    _28 = (gru).forward9(argument_4, x, argument_5, argument_6, )
    _29 = (flow_head).forward9(_28, )
    mask9 = torch.mul((mask).forward9(_28, ), CONSTANTS.c6)
    return (_29, mask9, _28, _28, _28)
  def forward10(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input10: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _30 = (encoder).forward10(input, input10, )
    x = torch.cat([inp, _30], 1)
    _31 = (gru).forward10(argument_4, x, argument_5, argument_6, )
    _32 = (flow_head).forward10(_31, )
    mask10 = torch.mul((mask).forward10(_31, ), CONSTANTS.c6)
    return (_32, mask10, _31, _31, _31)
  def forward11(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input11: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _33 = (encoder).forward11(input, input11, )
    x = torch.cat([inp, _33], 1)
    _34 = (gru).forward11(argument_4, x, argument_5, argument_6, )
    _35 = (flow_head).forward11(_34, )
    mask11 = torch.mul((mask).forward11(_34, ), CONSTANTS.c6)
    return (_35, mask11, _34, _34, _34)
  def forward12(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input12: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _36 = (encoder).forward12(input, input12, )
    x = torch.cat([inp, _36], 1)
    _37 = (gru).forward12(argument_4, x, argument_5, argument_6, )
    _38 = (flow_head).forward12(_37, )
    mask12 = torch.mul((mask).forward12(_37, ), CONSTANTS.c6)
    return (_38, mask12, _37, _37, _37)
  def forward13(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input13: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _39 = (encoder).forward13(input, input13, )
    x = torch.cat([inp, _39], 1)
    _40 = (gru).forward13(argument_4, x, argument_5, argument_6, )
    _41 = (flow_head).forward13(_40, )
    mask13 = torch.mul((mask).forward13(_40, ), CONSTANTS.c6)
    return (_41, mask13, _40, _40, _40)
  def forward14(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input14: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _42 = (encoder).forward14(input, input14, )
    x = torch.cat([inp, _42], 1)
    _43 = (gru).forward14(argument_4, x, argument_5, argument_6, )
    _44 = (flow_head).forward14(_43, )
    mask14 = torch.mul((mask).forward14(_43, ), CONSTANTS.c6)
    return (_44, mask14, _43, _43, _43)
  def forward15(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input15: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _45 = (encoder).forward15(input, input15, )
    x = torch.cat([inp, _45], 1)
    _46 = (gru).forward15(argument_4, x, argument_5, argument_6, )
    _47 = (flow_head).forward15(_46, )
    mask15 = torch.mul((mask).forward15(_46, ), CONSTANTS.c6)
    return (_47, mask15, _46, _46, _46)
  def forward16(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input16: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _48 = (encoder).forward16(input, input16, )
    x = torch.cat([inp, _48], 1)
    _49 = (gru).forward16(argument_4, x, argument_5, argument_6, )
    _50 = (flow_head).forward16(_49, )
    mask16 = torch.mul((mask).forward16(_49, ), CONSTANTS.c6)
    return (_50, mask16, _49, _49, _49)
  def forward17(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input17: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _51 = (encoder).forward17(input, input17, )
    x = torch.cat([inp, _51], 1)
    _52 = (gru).forward17(argument_4, x, argument_5, argument_6, )
    _53 = (flow_head).forward17(_52, )
    mask17 = torch.mul((mask).forward17(_52, ), CONSTANTS.c6)
    return (_53, mask17, _52, _52, _52)
  def forward18(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input18: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _54 = (encoder).forward18(input, input18, )
    x = torch.cat([inp, _54], 1)
    _55 = (gru).forward18(argument_4, x, argument_5, argument_6, )
    _56 = (flow_head).forward18(_55, )
    mask18 = torch.mul((mask).forward18(_55, ), CONSTANTS.c6)
    return (_56, mask18, _55, _55, _55)
  def forward19(self: __torch__.update.___torch_mangle_2732.BasicUpdateBlock,
    input: Tensor,
    input19: Tensor,
    inp: Tensor,
    argument_4: Tensor,
    argument_5: Tensor,
    argument_6: Tensor) -> Tuple[Tensor, Tensor]:
    mask = self.mask
    flow_head = self.flow_head
    gru = self.gru
    encoder = self.encoder
    _57 = (encoder).forward19(input, input19, )
    x = torch.cat([inp, _57], 1)
    _58 = (gru).forward19(argument_4, x, argument_5, argument_6, )
    _59 = (flow_head).forward19(_58, )
    mask19 = torch.mul((mask).forward19(_58, ), CONSTANTS.c6)
    return (_59, mask19)
