class BasicMotionEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  convc1 : __torch__.torch.nn.modules.conv.___torch_mangle_2711.Conv2d
  convc2 : __torch__.torch.nn.modules.conv.___torch_mangle_2712.Conv2d
  convf1 : __torch__.torch.nn.modules.conv.___torch_mangle_2713.Conv2d
  convf2 : __torch__.torch.nn.modules.conv.___torch_mangle_2714.Conv2d
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_2715.Conv2d
  def forward(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input0: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input1 = torch.relu((convc1).forward(input, ))
    cor = torch.relu((convc2).forward(input1, ))
    input2 = torch.relu((convf1).forward(input0, ))
    flo = torch.relu((convf2).forward(input2, ))
    input3 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward(input3, ))
    return torch.cat([out, input0], 1)
  def forward1(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input4: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input5 = torch.relu((convc1).forward1(input, ))
    cor = torch.relu((convc2).forward1(input5, ))
    input6 = torch.relu((convf1).forward1(input4, ))
    flo = torch.relu((convf2).forward1(input6, ))
    input7 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward1(input7, ))
    return torch.cat([out, input4], 1)
  def forward2(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input8: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input9 = torch.relu((convc1).forward2(input, ))
    cor = torch.relu((convc2).forward2(input9, ))
    input10 = torch.relu((convf1).forward2(input8, ))
    flo = torch.relu((convf2).forward2(input10, ))
    input11 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward2(input11, ))
    return torch.cat([out, input8], 1)
  def forward3(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input12: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input13 = torch.relu((convc1).forward3(input, ))
    cor = torch.relu((convc2).forward3(input13, ))
    input14 = torch.relu((convf1).forward3(input12, ))
    flo = torch.relu((convf2).forward3(input14, ))
    input15 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward3(input15, ))
    return torch.cat([out, input12], 1)
  def forward4(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input16: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input17 = torch.relu((convc1).forward4(input, ))
    cor = torch.relu((convc2).forward4(input17, ))
    input18 = torch.relu((convf1).forward4(input16, ))
    flo = torch.relu((convf2).forward4(input18, ))
    input19 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward4(input19, ))
    return torch.cat([out, input16], 1)
  def forward5(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input20: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input21 = torch.relu((convc1).forward5(input, ))
    cor = torch.relu((convc2).forward5(input21, ))
    input22 = torch.relu((convf1).forward5(input20, ))
    flo = torch.relu((convf2).forward5(input22, ))
    input23 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward5(input23, ))
    return torch.cat([out, input20], 1)
  def forward6(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input24: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input25 = torch.relu((convc1).forward6(input, ))
    cor = torch.relu((convc2).forward6(input25, ))
    input26 = torch.relu((convf1).forward6(input24, ))
    flo = torch.relu((convf2).forward6(input26, ))
    input27 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward6(input27, ))
    return torch.cat([out, input24], 1)
  def forward7(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input28: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input29 = torch.relu((convc1).forward7(input, ))
    cor = torch.relu((convc2).forward7(input29, ))
    input30 = torch.relu((convf1).forward7(input28, ))
    flo = torch.relu((convf2).forward7(input30, ))
    input31 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward7(input31, ))
    return torch.cat([out, input28], 1)
  def forward8(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input32: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input33 = torch.relu((convc1).forward8(input, ))
    cor = torch.relu((convc2).forward8(input33, ))
    input34 = torch.relu((convf1).forward8(input32, ))
    flo = torch.relu((convf2).forward8(input34, ))
    input35 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward8(input35, ))
    return torch.cat([out, input32], 1)
  def forward9(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input36: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input37 = torch.relu((convc1).forward9(input, ))
    cor = torch.relu((convc2).forward9(input37, ))
    input38 = torch.relu((convf1).forward9(input36, ))
    flo = torch.relu((convf2).forward9(input38, ))
    input39 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward9(input39, ))
    return torch.cat([out, input36], 1)
  def forward10(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input40: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input41 = torch.relu((convc1).forward10(input, ))
    cor = torch.relu((convc2).forward10(input41, ))
    input42 = torch.relu((convf1).forward10(input40, ))
    flo = torch.relu((convf2).forward10(input42, ))
    input43 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward10(input43, ))
    return torch.cat([out, input40], 1)
  def forward11(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input44: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input45 = torch.relu((convc1).forward11(input, ))
    cor = torch.relu((convc2).forward11(input45, ))
    input46 = torch.relu((convf1).forward11(input44, ))
    flo = torch.relu((convf2).forward11(input46, ))
    input47 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward11(input47, ))
    return torch.cat([out, input44], 1)
  def forward12(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input48: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input49 = torch.relu((convc1).forward12(input, ))
    cor = torch.relu((convc2).forward12(input49, ))
    input50 = torch.relu((convf1).forward12(input48, ))
    flo = torch.relu((convf2).forward12(input50, ))
    input51 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward12(input51, ))
    return torch.cat([out, input48], 1)
  def forward13(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input52: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input53 = torch.relu((convc1).forward13(input, ))
    cor = torch.relu((convc2).forward13(input53, ))
    input54 = torch.relu((convf1).forward13(input52, ))
    flo = torch.relu((convf2).forward13(input54, ))
    input55 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward13(input55, ))
    return torch.cat([out, input52], 1)
  def forward14(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input56: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input57 = torch.relu((convc1).forward14(input, ))
    cor = torch.relu((convc2).forward14(input57, ))
    input58 = torch.relu((convf1).forward14(input56, ))
    flo = torch.relu((convf2).forward14(input58, ))
    input59 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward14(input59, ))
    return torch.cat([out, input56], 1)
  def forward15(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input60: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input61 = torch.relu((convc1).forward15(input, ))
    cor = torch.relu((convc2).forward15(input61, ))
    input62 = torch.relu((convf1).forward15(input60, ))
    flo = torch.relu((convf2).forward15(input62, ))
    input63 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward15(input63, ))
    return torch.cat([out, input60], 1)
  def forward16(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input64: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input65 = torch.relu((convc1).forward16(input, ))
    cor = torch.relu((convc2).forward16(input65, ))
    input66 = torch.relu((convf1).forward16(input64, ))
    flo = torch.relu((convf2).forward16(input66, ))
    input67 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward16(input67, ))
    return torch.cat([out, input64], 1)
  def forward17(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input68: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input69 = torch.relu((convc1).forward17(input, ))
    cor = torch.relu((convc2).forward17(input69, ))
    input70 = torch.relu((convf1).forward17(input68, ))
    flo = torch.relu((convf2).forward17(input70, ))
    input71 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward17(input71, ))
    return torch.cat([out, input68], 1)
  def forward18(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input72: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input73 = torch.relu((convc1).forward18(input, ))
    cor = torch.relu((convc2).forward18(input73, ))
    input74 = torch.relu((convf1).forward18(input72, ))
    flo = torch.relu((convf2).forward18(input74, ))
    input75 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward18(input75, ))
    return torch.cat([out, input72], 1)
  def forward19(self: __torch__.update.___torch_mangle_2716.BasicMotionEncoder,
    input: Tensor,
    input76: Tensor) -> Tensor:
    conv = self.conv
    convf2 = self.convf2
    convf1 = self.convf1
    convc2 = self.convc2
    convc1 = self.convc1
    input77 = torch.relu((convc1).forward19(input, ))
    cor = torch.relu((convc2).forward19(input77, ))
    input78 = torch.relu((convf1).forward19(input76, ))
    flo = torch.relu((convf2).forward19(input78, ))
    input79 = torch.cat([cor, flo], 1)
    out = torch.relu((conv).forward19(input79, ))
    return torch.cat([out, input76], 1)
