class FlowHead(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_2724.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_2725.Conv2d
  relu : __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU
  def forward(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _0 = (relu).forward((conv1).forward(argument_1, ), )
    return (conv2).forward(_0, )
  def forward1(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _1 = (relu).forward1((conv1).forward1(argument_1, ), )
    return (conv2).forward1(_1, )
  def forward2(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _2 = (relu).forward2((conv1).forward2(argument_1, ), )
    return (conv2).forward2(_2, )
  def forward3(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _3 = (relu).forward3((conv1).forward3(argument_1, ), )
    return (conv2).forward3(_3, )
  def forward4(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _4 = (relu).forward4((conv1).forward4(argument_1, ), )
    return (conv2).forward4(_4, )
  def forward5(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _5 = (relu).forward5((conv1).forward5(argument_1, ), )
    return (conv2).forward5(_5, )
  def forward6(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _6 = (relu).forward6((conv1).forward6(argument_1, ), )
    return (conv2).forward6(_6, )
  def forward7(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _7 = (relu).forward7((conv1).forward7(argument_1, ), )
    return (conv2).forward7(_7, )
  def forward8(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _8 = (relu).forward8((conv1).forward8(argument_1, ), )
    return (conv2).forward8(_8, )
  def forward9(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _9 = (relu).forward9((conv1).forward9(argument_1, ), )
    return (conv2).forward9(_9, )
  def forward10(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _10 = (relu).forward10((conv1).forward10(argument_1, ), )
    return (conv2).forward10(_10, )
  def forward11(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _11 = (relu).forward11((conv1).forward11(argument_1, ), )
    return (conv2).forward11(_11, )
  def forward12(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _12 = (relu).forward12((conv1).forward12(argument_1, ), )
    return (conv2).forward12(_12, )
  def forward13(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _13 = (relu).forward13((conv1).forward13(argument_1, ), )
    return (conv2).forward13(_13, )
  def forward14(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _14 = (relu).forward14((conv1).forward14(argument_1, ), )
    return (conv2).forward14(_14, )
  def forward15(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _15 = (relu).forward15((conv1).forward15(argument_1, ), )
    return (conv2).forward15(_15, )
  def forward16(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _16 = (relu).forward16((conv1).forward16(argument_1, ), )
    return (conv2).forward16(_16, )
  def forward17(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _17 = (relu).forward17((conv1).forward17(argument_1, ), )
    return (conv2).forward17(_17, )
  def forward18(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _18 = (relu).forward18((conv1).forward18(argument_1, ), )
    return (conv2).forward18(_18, )
  def forward19(self: __torch__.update.___torch_mangle_2727.FlowHead,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    relu = self.relu
    conv1 = self.conv1
    _19 = (relu).forward19((conv1).forward19(argument_1, ), )
    return (conv2).forward19(_19, )
