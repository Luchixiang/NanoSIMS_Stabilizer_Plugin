class SepConvGRU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  convz1 : __torch__.torch.nn.modules.conv.___torch_mangle_2717.Conv2d
  convr1 : __torch__.torch.nn.modules.conv.___torch_mangle_2718.Conv2d
  convq1 : __torch__.torch.nn.modules.conv.___torch_mangle_2719.Conv2d
  convz2 : __torch__.torch.nn.modules.conv.___torch_mangle_2720.Conv2d
  convr2 : __torch__.torch.nn.modules.conv.___torch_mangle_2721.Conv2d
  convq2 : __torch__.torch.nn.modules.conv.___torch_mangle_2722.Conv2d
  def forward(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    h: Tensor,
    x: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([h, x], 1)
    z = torch.sigmoid((convz1).forward(input, ))
    r = torch.sigmoid((convr1).forward(input, ))
    input0 = torch.cat([torch.mul(r, h), x], 1)
    q = torch.tanh((convq1).forward(input0, ))
    h0 = torch.add(torch.mul(torch.rsub(z, 1), h), torch.mul(z, q))
    input1 = torch.cat([h0, x], 1)
    z0 = torch.sigmoid((convz2).forward(input1, ))
    r0 = torch.sigmoid((convr2).forward(input1, ))
    input2 = torch.cat([torch.mul(r0, h0), x], 1)
    q0 = torch.tanh((convq2).forward(input2, ))
    input3 = torch.add(torch.mul(torch.rsub(z0, 1), h0), torch.mul(z0, q0))
    return input3
  def forward1(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward1(input, ))
    r = torch.sigmoid((convr1).forward1(input, ))
    input4 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward1(input4, ))
    _0 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_0, torch.mul(z, q))
    input5 = torch.cat([h, x], 1)
    z1 = torch.sigmoid((convz2).forward1(input5, ))
    r1 = torch.sigmoid((convr2).forward1(input5, ))
    input6 = torch.cat([torch.mul(r1, h), x], 1)
    q1 = torch.tanh((convq2).forward1(input6, ))
    input7 = torch.add(torch.mul(torch.rsub(z1, 1), h), torch.mul(z1, q1))
    return input7
  def forward2(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward2(input, ))
    r = torch.sigmoid((convr1).forward2(input, ))
    input8 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward2(input8, ))
    _1 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_1, torch.mul(z, q))
    input9 = torch.cat([h, x], 1)
    z2 = torch.sigmoid((convz2).forward2(input9, ))
    r2 = torch.sigmoid((convr2).forward2(input9, ))
    input10 = torch.cat([torch.mul(r2, h), x], 1)
    q2 = torch.tanh((convq2).forward2(input10, ))
    input11 = torch.add(torch.mul(torch.rsub(z2, 1), h), torch.mul(z2, q2))
    return input11
  def forward3(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward3(input, ))
    r = torch.sigmoid((convr1).forward3(input, ))
    input12 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward3(input12, ))
    _2 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_2, torch.mul(z, q))
    input13 = torch.cat([h, x], 1)
    z3 = torch.sigmoid((convz2).forward3(input13, ))
    r3 = torch.sigmoid((convr2).forward3(input13, ))
    input14 = torch.cat([torch.mul(r3, h), x], 1)
    q3 = torch.tanh((convq2).forward3(input14, ))
    input15 = torch.add(torch.mul(torch.rsub(z3, 1), h), torch.mul(z3, q3))
    return input15
  def forward4(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward4(input, ))
    r = torch.sigmoid((convr1).forward4(input, ))
    input16 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward4(input16, ))
    _3 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_3, torch.mul(z, q))
    input17 = torch.cat([h, x], 1)
    z4 = torch.sigmoid((convz2).forward4(input17, ))
    r4 = torch.sigmoid((convr2).forward4(input17, ))
    input18 = torch.cat([torch.mul(r4, h), x], 1)
    q4 = torch.tanh((convq2).forward4(input18, ))
    input19 = torch.add(torch.mul(torch.rsub(z4, 1), h), torch.mul(z4, q4))
    return input19
  def forward5(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward5(input, ))
    r = torch.sigmoid((convr1).forward5(input, ))
    input20 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward5(input20, ))
    _4 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_4, torch.mul(z, q))
    input21 = torch.cat([h, x], 1)
    z5 = torch.sigmoid((convz2).forward5(input21, ))
    r5 = torch.sigmoid((convr2).forward5(input21, ))
    input22 = torch.cat([torch.mul(r5, h), x], 1)
    q5 = torch.tanh((convq2).forward5(input22, ))
    input23 = torch.add(torch.mul(torch.rsub(z5, 1), h), torch.mul(z5, q5))
    return input23
  def forward6(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward6(input, ))
    r = torch.sigmoid((convr1).forward6(input, ))
    input24 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward6(input24, ))
    _5 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_5, torch.mul(z, q))
    input25 = torch.cat([h, x], 1)
    z6 = torch.sigmoid((convz2).forward6(input25, ))
    r6 = torch.sigmoid((convr2).forward6(input25, ))
    input26 = torch.cat([torch.mul(r6, h), x], 1)
    q6 = torch.tanh((convq2).forward6(input26, ))
    input27 = torch.add(torch.mul(torch.rsub(z6, 1), h), torch.mul(z6, q6))
    return input27
  def forward7(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward7(input, ))
    r = torch.sigmoid((convr1).forward7(input, ))
    input28 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward7(input28, ))
    _6 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_6, torch.mul(z, q))
    input29 = torch.cat([h, x], 1)
    z7 = torch.sigmoid((convz2).forward7(input29, ))
    r7 = torch.sigmoid((convr2).forward7(input29, ))
    input30 = torch.cat([torch.mul(r7, h), x], 1)
    q7 = torch.tanh((convq2).forward7(input30, ))
    input31 = torch.add(torch.mul(torch.rsub(z7, 1), h), torch.mul(z7, q7))
    return input31
  def forward8(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward8(input, ))
    r = torch.sigmoid((convr1).forward8(input, ))
    input32 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward8(input32, ))
    _7 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_7, torch.mul(z, q))
    input33 = torch.cat([h, x], 1)
    z8 = torch.sigmoid((convz2).forward8(input33, ))
    r8 = torch.sigmoid((convr2).forward8(input33, ))
    input34 = torch.cat([torch.mul(r8, h), x], 1)
    q8 = torch.tanh((convq2).forward8(input34, ))
    input35 = torch.add(torch.mul(torch.rsub(z8, 1), h), torch.mul(z8, q8))
    return input35
  def forward9(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward9(input, ))
    r = torch.sigmoid((convr1).forward9(input, ))
    input36 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward9(input36, ))
    _8 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_8, torch.mul(z, q))
    input37 = torch.cat([h, x], 1)
    z9 = torch.sigmoid((convz2).forward9(input37, ))
    r9 = torch.sigmoid((convr2).forward9(input37, ))
    input38 = torch.cat([torch.mul(r9, h), x], 1)
    q9 = torch.tanh((convq2).forward9(input38, ))
    input39 = torch.add(torch.mul(torch.rsub(z9, 1), h), torch.mul(z9, q9))
    return input39
  def forward10(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward10(input, ))
    r = torch.sigmoid((convr1).forward10(input, ))
    input40 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward10(input40, ))
    _9 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_9, torch.mul(z, q))
    input41 = torch.cat([h, x], 1)
    z10 = torch.sigmoid((convz2).forward10(input41, ))
    r10 = torch.sigmoid((convr2).forward10(input41, ))
    input42 = torch.cat([torch.mul(r10, h), x], 1)
    q10 = torch.tanh((convq2).forward10(input42, ))
    input43 = torch.add(torch.mul(torch.rsub(z10, 1), h), torch.mul(z10, q10))
    return input43
  def forward11(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward11(input, ))
    r = torch.sigmoid((convr1).forward11(input, ))
    input44 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward11(input44, ))
    _10 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_10, torch.mul(z, q))
    input45 = torch.cat([h, x], 1)
    z11 = torch.sigmoid((convz2).forward11(input45, ))
    r11 = torch.sigmoid((convr2).forward11(input45, ))
    input46 = torch.cat([torch.mul(r11, h), x], 1)
    q11 = torch.tanh((convq2).forward11(input46, ))
    input47 = torch.add(torch.mul(torch.rsub(z11, 1), h), torch.mul(z11, q11))
    return input47
  def forward12(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward12(input, ))
    r = torch.sigmoid((convr1).forward12(input, ))
    input48 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward12(input48, ))
    _11 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_11, torch.mul(z, q))
    input49 = torch.cat([h, x], 1)
    z12 = torch.sigmoid((convz2).forward12(input49, ))
    r12 = torch.sigmoid((convr2).forward12(input49, ))
    input50 = torch.cat([torch.mul(r12, h), x], 1)
    q12 = torch.tanh((convq2).forward12(input50, ))
    input51 = torch.add(torch.mul(torch.rsub(z12, 1), h), torch.mul(z12, q12))
    return input51
  def forward13(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward13(input, ))
    r = torch.sigmoid((convr1).forward13(input, ))
    input52 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward13(input52, ))
    _12 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_12, torch.mul(z, q))
    input53 = torch.cat([h, x], 1)
    z13 = torch.sigmoid((convz2).forward13(input53, ))
    r13 = torch.sigmoid((convr2).forward13(input53, ))
    input54 = torch.cat([torch.mul(r13, h), x], 1)
    q13 = torch.tanh((convq2).forward13(input54, ))
    input55 = torch.add(torch.mul(torch.rsub(z13, 1), h), torch.mul(z13, q13))
    return input55
  def forward14(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward14(input, ))
    r = torch.sigmoid((convr1).forward14(input, ))
    input56 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward14(input56, ))
    _13 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_13, torch.mul(z, q))
    input57 = torch.cat([h, x], 1)
    z14 = torch.sigmoid((convz2).forward14(input57, ))
    r14 = torch.sigmoid((convr2).forward14(input57, ))
    input58 = torch.cat([torch.mul(r14, h), x], 1)
    q14 = torch.tanh((convq2).forward14(input58, ))
    input59 = torch.add(torch.mul(torch.rsub(z14, 1), h), torch.mul(z14, q14))
    return input59
  def forward15(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward15(input, ))
    r = torch.sigmoid((convr1).forward15(input, ))
    input60 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward15(input60, ))
    _14 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_14, torch.mul(z, q))
    input61 = torch.cat([h, x], 1)
    z15 = torch.sigmoid((convz2).forward15(input61, ))
    r15 = torch.sigmoid((convr2).forward15(input61, ))
    input62 = torch.cat([torch.mul(r15, h), x], 1)
    q15 = torch.tanh((convq2).forward15(input62, ))
    input63 = torch.add(torch.mul(torch.rsub(z15, 1), h), torch.mul(z15, q15))
    return input63
  def forward16(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward16(input, ))
    r = torch.sigmoid((convr1).forward16(input, ))
    input64 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward16(input64, ))
    _15 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_15, torch.mul(z, q))
    input65 = torch.cat([h, x], 1)
    z16 = torch.sigmoid((convz2).forward16(input65, ))
    r16 = torch.sigmoid((convr2).forward16(input65, ))
    input66 = torch.cat([torch.mul(r16, h), x], 1)
    q16 = torch.tanh((convq2).forward16(input66, ))
    input67 = torch.add(torch.mul(torch.rsub(z16, 1), h), torch.mul(z16, q16))
    return input67
  def forward17(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward17(input, ))
    r = torch.sigmoid((convr1).forward17(input, ))
    input68 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward17(input68, ))
    _16 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_16, torch.mul(z, q))
    input69 = torch.cat([h, x], 1)
    z17 = torch.sigmoid((convz2).forward17(input69, ))
    r17 = torch.sigmoid((convr2).forward17(input69, ))
    input70 = torch.cat([torch.mul(r17, h), x], 1)
    q17 = torch.tanh((convq2).forward17(input70, ))
    input71 = torch.add(torch.mul(torch.rsub(z17, 1), h), torch.mul(z17, q17))
    return input71
  def forward18(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward18(input, ))
    r = torch.sigmoid((convr1).forward18(input, ))
    input72 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward18(input72, ))
    _17 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_17, torch.mul(z, q))
    input73 = torch.cat([h, x], 1)
    z18 = torch.sigmoid((convz2).forward18(input73, ))
    r18 = torch.sigmoid((convr2).forward18(input73, ))
    input74 = torch.cat([torch.mul(r18, h), x], 1)
    q18 = torch.tanh((convq2).forward18(input74, ))
    input75 = torch.add(torch.mul(torch.rsub(z18, 1), h), torch.mul(z18, q18))
    return input75
  def forward19(self: __torch__.update.___torch_mangle_2723.SepConvGRU,
    argument_1: Tensor,
    x: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    convq2 = self.convq2
    convr2 = self.convr2
    convz2 = self.convz2
    convq1 = self.convq1
    convr1 = self.convr1
    convz1 = self.convz1
    input = torch.cat([argument_1, x], 1)
    z = torch.sigmoid((convz1).forward19(input, ))
    r = torch.sigmoid((convr1).forward19(input, ))
    input76 = torch.cat([torch.mul(r, argument_3), x], 1)
    q = torch.tanh((convq1).forward19(input76, ))
    _18 = torch.mul(torch.rsub(z, 1), argument_4)
    h = torch.add(_18, torch.mul(z, q))
    input77 = torch.cat([h, x], 1)
    z19 = torch.sigmoid((convz2).forward19(input77, ))
    r19 = torch.sigmoid((convr2).forward19(input77, ))
    input78 = torch.cat([torch.mul(r19, h), x], 1)
    q19 = torch.tanh((convq2).forward19(input78, ))
    input79 = torch.add(torch.mul(torch.rsub(z19, 1), h), torch.mul(z19, q19))
    return input79
