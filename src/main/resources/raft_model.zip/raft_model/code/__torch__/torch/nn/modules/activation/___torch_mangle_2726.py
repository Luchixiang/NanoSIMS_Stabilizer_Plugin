class ReLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward1(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward2(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward3(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward4(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward5(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward6(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward7(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward8(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward9(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward10(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward11(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward12(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward13(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward14(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward15(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward16(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward17(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward18(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
  def forward19(self: __torch__.torch.nn.modules.activation.___torch_mangle_2726.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
