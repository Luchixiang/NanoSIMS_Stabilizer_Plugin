class BasicEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm1 : __torch__.torch.nn.modules.instancenorm.___torch_mangle_2607.InstanceNorm2d
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_2608.Conv2d
  relu1 : __torch__.torch.nn.modules.activation.___torch_mangle_2609.ReLU
  layer1 : __torch__.torch.nn.modules.container.___torch_mangle_2622.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_2639.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_2656.Sequential
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_2657.Conv2d
  def forward(self: __torch__.extractor.___torch_mangle_2658.BasicEncoder,
    input: Tensor,
    argument_2: Tensor) -> Tuple[Tensor, Tensor]:
    conv2 = self.conv2
    layer3 = self.layer3
    layer2 = self.layer2
    layer1 = self.layer1
    relu1 = self.relu1
    norm1 = self.norm1
    conv1 = self.conv1
    _0 = ops.prim.NumToTensor(torch.size(input, 0))
    _1 = int(_0)
    _2 = int(_0)
    input0 = torch.cat([input, argument_2])
    _3 = (norm1).forward((conv1).forward(input0, ), )
    _4 = (layer1).forward((relu1).forward(_3, ), )
    _5 = (layer3).forward((layer2).forward(_4, ), )
    _6 = torch.split_with_sizes((conv2).forward(_5, ), [_2, _1])
    fmap1, fmap2, = _6
    return (fmap1, fmap2)
