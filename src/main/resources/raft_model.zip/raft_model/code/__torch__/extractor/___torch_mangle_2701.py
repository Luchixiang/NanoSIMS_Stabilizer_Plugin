class ResidualBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_2692.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_2693.Conv2d
  relu : __torch__.torch.nn.modules.activation.___torch_mangle_2694.ReLU
  norm1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_2695.BatchNorm2d
  norm2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_2696.BatchNorm2d
  norm3 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_2697.BatchNorm2d
  downsample : __torch__.torch.nn.modules.container.___torch_mangle_2700.Sequential
  def forward(self: __torch__.extractor.___torch_mangle_2701.ResidualBlock,
    argument_1: Tensor) -> Tensor:
    norm3 = self.norm3
    running_var = norm3.running_var
    norm30 = self.norm3
    running_mean = norm30.running_mean
    norm31 = self.norm3
    bias = norm31.bias
    norm32 = self.norm3
    weight = norm32.weight
    downsample = self.downsample
    norm2 = self.norm2
    conv2 = self.conv2
    relu = self.relu
    norm1 = self.norm1
    conv1 = self.conv1
    _0 = (norm1).forward((conv1).forward(argument_1, ), )
    _1 = (conv2).forward((relu).forward(_0, ), )
    _2 = (relu).forward1((norm2).forward(_1, ), )
    _3 = (downsample).forward(weight, bias, running_mean, running_var, argument_1, )
    input = torch.add(_3, _2)
    return (relu).forward2(input, )
