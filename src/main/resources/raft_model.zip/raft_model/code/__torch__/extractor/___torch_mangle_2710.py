class BasicEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_2659.BatchNorm2d
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_2660.Conv2d
  relu1 : __torch__.torch.nn.modules.activation.___torch_mangle_2661.ReLU
  layer1 : __torch__.torch.nn.modules.container.___torch_mangle_2674.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_2691.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_2708.Sequential
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_2709.Conv2d
  def forward(self: __torch__.extractor.___torch_mangle_2710.BasicEncoder,
    input: Tensor) -> Tensor:
    conv2 = self.conv2
    layer3 = self.layer3
    layer2 = self.layer2
    layer1 = self.layer1
    relu1 = self.relu1
    norm1 = self.norm1
    conv1 = self.conv1
    _0 = (norm1).forward((conv1).forward(input, ), )
    _1 = (layer1).forward((relu1).forward(_0, ), )
    _2 = (layer3).forward((layer2).forward(_1, ), )
    return (conv2).forward(_2, )
