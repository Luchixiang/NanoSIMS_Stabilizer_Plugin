class ResidualBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_2623.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_2624.Conv2d
  relu : __torch__.torch.nn.modules.activation.___torch_mangle_2625.ReLU
  norm1 : __torch__.torch.nn.modules.instancenorm.___torch_mangle_2626.InstanceNorm2d
  norm2 : __torch__.torch.nn.modules.instancenorm.___torch_mangle_2627.InstanceNorm2d
  norm3 : __torch__.torch.nn.modules.instancenorm.___torch_mangle_2628.InstanceNorm2d
  downsample : __torch__.torch.nn.modules.container.___torch_mangle_2631.Sequential
  def forward(self: __torch__.extractor.___torch_mangle_2632.ResidualBlock,
    argument_1: Tensor) -> Tensor:
    downsample = self.downsample
    norm2 = self.norm2
    conv2 = self.conv2
    relu = self.relu
    norm1 = self.norm1
    conv1 = self.conv1
    _0 = (norm1).forward((conv1).forward(argument_1, ), )
    _1 = (conv2).forward((relu).forward(_0, ), )
    _2 = (relu).forward1((norm2).forward(_1, ), )
    input = torch.add((downsample).forward(argument_1, ), _2)
    return (relu).forward2(input, )
